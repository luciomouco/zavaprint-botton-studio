import { jsPDF } from 'jspdf';
import {
  BleedType,
  BottonArtwork,
  ButtonShape,
  CutLineOptions,
  FoilMatrixOptions,
  LayoutCalculation,
} from '../types/button';
import { applyFoilFilter, loadImage } from './imageProcessing';

export interface ExportProgressCallback {
  (current: number, total: number, message: string): void;
}

/**
 * Draws shape path on 2D canvas context for round, square, rectangle, and heart
 */
export function drawShapePath(
  ctx: CanvasRenderingContext2D,
  shape: ButtonShape,
  cx: number,
  cy: number,
  w: number,
  h: number,
  radius: number = 4
) {
  ctx.beginPath();
  if (shape === 'round') {
    ctx.arc(cx, cy, w / 2, 0, Math.PI * 2);
  } else if (shape === 'square' || shape === 'rectangle') {
    if (ctx.roundRect) {
      ctx.roundRect(cx - w / 2, cy - h / 2, w, h, radius);
    } else {
      ctx.rect(cx - w / 2, cy - h / 2, w, h);
    }
  } else if (shape === 'heart') {
    const topY = cy - h * 0.45;
    const botY = cy + h * 0.45;
    const leftX = cx - w * 0.48;
    const rightX = cx + w * 0.48;
    const midTopY = cy - h * 0.18;

    ctx.moveTo(cx, midTopY);
    ctx.bezierCurveTo(cx, topY - h * 0.15, leftX, topY, leftX, cy - h * 0.08);
    ctx.bezierCurveTo(leftX, cy + h * 0.2, cx - w * 0.15, cy + h * 0.33, cx, botY);
    ctx.bezierCurveTo(cx + w * 0.15, cy + h * 0.33, rightX, cy + h * 0.2, rightX, cy - h * 0.08);
    ctx.bezierCurveTo(rightX, topY, cx, topY - h * 0.15, cx, midTopY);
    ctx.closePath();
  }
}

/**
 * Prepares and renders a single button graphic onto an offscreen canvas at high resolution
 * Supports all 4 bleed options:
 * 1. image_continuous: uses the artwork itself to fill the bleed rim all the way to cut edge
 * 2. image_mirror: mirrors the artwork edges into the bleed zone
 * 3. image_blur: soft ambient blurred bleed from the artwork colors
 * 4. solid_color: custom solid color in the bleed rim with art confined to face
 */
export async function renderButtonCanvas(
  art: BottonArtwork | undefined,
  layout: LayoutCalculation,
  foilOptions: FoilMatrixOptions,
  targetPxWidth: number = 750
): Promise<HTMLCanvasElement | null> {
  const outerW = layout.outerDiameterMm;
  const outerH = layout.outerSecondaryMm || outerW;
  const innerW = layout.innerDiameterMm;
  const innerH = layout.innerSecondaryMm || innerW;
  const shape = layout.shape;

  const aspectRatio = outerH / outerW;
  const targetPxHeight = Math.round(targetPxWidth * aspectRatio);

  const canvas = document.createElement('canvas');
  canvas.width = targetPxWidth;
  canvas.height = targetPxHeight;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  const cx = targetPxWidth / 2;
  const cy = targetPxHeight / 2;
  const mmToPx = targetPxWidth / outerW;

  const innerPxW = innerW * mmToPx;
  const innerPxH = innerH * mmToPx;

  const bleedType: BleedType = art?.bleedType || 'image_continuous';
  const bleedColor = art?.bleedColor || '#ffffff';
  const faceBgColor = art?.faceBgColor || '#ffffff';

  // Base background fill
  ctx.save();
  drawShapePath(ctx, shape, cx, cy, targetPxWidth, targetPxHeight, 10);
  ctx.fillStyle = bleedType === 'solid_color' ? bleedColor : (faceBgColor || '#ffffff');
  ctx.fill();
  ctx.restore();

  if (art && art.dataUrl) {
    const effectiveUrl = foilOptions.enabled
      ? await applyFoilFilter(art.dataUrl, foilOptions)
      : art.dataUrl;

    const img = await loadImage(effectiveUrl);

    const imgAspect = img.naturalWidth / img.naturalHeight;
    const scale = art.scale || 1.0;
    const panXPx = (art.panX || 0) * mmToPx;
    const panYPx = (art.panY || 0) * mmToPx;
    const rotation = art.rotation || 0;

    // Helper to calculate draw dimensions
    const calcDrawSize = (baseW: number, baseH: number, s: number) => {
      let dW = baseW * s;
      let dH = baseH * s;
      if (imgAspect > baseW / baseH) {
        dW = baseH * s * imgAspect;
      } else {
        dH = (baseW * s) / imgAspect;
      }
      return { dW, dH };
    };

    if (bleedType === 'image_continuous') {
      // 1. SANGIA COM A PRÓPRIA IMAGEM (Contínua):
      // The image covers both face and bleed continuously!
      ctx.save();
      drawShapePath(ctx, shape, cx, cy, targetPxWidth, targetPxHeight, 10);
      ctx.clip();

      ctx.translate(cx + panXPx, cy + panYPx);
      if (rotation) ctx.rotate((rotation * Math.PI) / 180);

      const { dW, dH } = calcDrawSize(targetPxWidth, targetPxHeight, scale);
      ctx.drawImage(img, -dW / 2, -dH / 2, dW, dH);
      ctx.restore();

    } else if (bleedType === 'image_mirror') {
      // 2. SANGRIA ESPELHADA (Borda Espelho com a própria imagem):
      // Background bleed layer: flipped image
      ctx.save();
      drawShapePath(ctx, shape, cx, cy, targetPxWidth, targetPxHeight, 10);
      ctx.clip();

      ctx.translate(cx + panXPx, cy + panYPx);
      if (rotation) ctx.rotate((rotation * Math.PI) / 180);
      ctx.scale(-1.15, -1.15); // mirror expansion

      const { dW: bgW, dH: bgH } = calcDrawSize(targetPxWidth, targetPxHeight, scale);
      ctx.drawImage(img, -bgW / 2, -bgH / 2, bgW, bgH);
      ctx.restore();

      // Sharp foreground image inside the face
      ctx.save();
      drawShapePath(ctx, shape, cx, cy, innerPxW, innerPxH, 8);
      ctx.clip();

      ctx.translate(cx + panXPx, cy + panYPx);
      if (rotation) ctx.rotate((rotation * Math.PI) / 180);

      const { dW, dH } = calcDrawSize(innerPxW, innerPxH, scale);
      ctx.drawImage(img, -dW / 2, -dH / 2, dW, dH);
      ctx.restore();

    } else if (bleedType === 'image_blur') {
      // 3. SANGRIA COM DESFOQUE DA PRÓPRIA IMAGEM (Soft Ambient Bleed):
      ctx.save();
      drawShapePath(ctx, shape, cx, cy, targetPxWidth, targetPxHeight, 10);
      ctx.clip();

      ctx.translate(cx + panXPx, cy + panYPx);
      if (rotation) ctx.rotate((rotation * Math.PI) / 180);

      const { dW: bgW, dH: bgH } = calcDrawSize(targetPxWidth * 1.15, targetPxHeight * 1.15, scale);
      ctx.filter = 'blur(10px) brightness(1.05)';
      ctx.drawImage(img, -bgW / 2, -bgH / 2, bgW, bgH);
      ctx.restore();

      // Sharp original image inside face
      ctx.save();
      drawShapePath(ctx, shape, cx, cy, innerPxW, innerPxH, 8);
      ctx.clip();

      ctx.translate(cx + panXPx, cy + panYPx);
      if (rotation) ctx.rotate((rotation * Math.PI) / 180);

      const { dW, dH } = calcDrawSize(innerPxW, innerPxH, scale);
      ctx.drawImage(img, -dW / 2, -dH / 2, dW, dH);
      ctx.restore();

    } else {
      // 4. SANGRIA COM COR SÓLIDA (Arte restrita à face):
      // The outer rim already has bleedColor. Now render art strictly inside the face.
      ctx.save();
      if (faceBgColor && faceBgColor !== 'transparent') {
        drawShapePath(ctx, shape, cx, cy, innerPxW, innerPxH, 8);
        ctx.fillStyle = faceBgColor;
        ctx.fill();
      }

      drawShapePath(ctx, shape, cx, cy, innerPxW, innerPxH, 8);
      ctx.clip();

      ctx.translate(cx + panXPx, cy + panYPx);
      if (rotation) ctx.rotate((rotation * Math.PI) / 180);

      const { dW, dH } = calcDrawSize(innerPxW, innerPxH, scale);
      ctx.drawImage(img, -dW / 2, -dH / 2, dW, dH);
      ctx.restore();
    }
  }

  // Optional Rim Text in Bleed Area (e.g. ZavaPrint Credits)
  if (art?.rimText && art.rimText.trim().length > 0 && shape === 'round') {
    ctx.save();
    ctx.translate(cx, cy);
    const textRadius = (innerPxW / 2 + targetPxWidth / 2) / 2;
    const text = art.rimText.trim();
    ctx.font = `600 ${Math.max(12, Math.round(targetPxWidth * 0.024))}px "Plus Jakarta Sans", sans-serif`;
    ctx.fillStyle = art.rimTextColor || (bleedType === 'solid_color' && bleedColor === '#0f172a' ? '#ffffff' : '#475569');
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const angleStep = 0.055;
    const startAngle = Math.PI / 2 - (text.length * angleStep) / 2;

    for (let i = 0; i < text.length; i++) {
      const angle = startAngle + i * angleStep;
      ctx.save();
      ctx.rotate(angle);
      ctx.translate(0, textRadius);
      ctx.fillText(text[i], 0, 0);
      ctx.restore();
    }
    ctx.restore();
  }

  return canvas;
}

/**
 * Export high-resolution A4 sheet to PDF using jsPDF
 */
export async function exportToPdf(
  layout: LayoutCalculation,
  artworks: Record<number, BottonArtwork>,
  defaultArt: BottonArtwork | null,
  cutLineOptions: CutLineOptions,
  foilOptions: FoilMatrixOptions,
  onProgress?: ExportProgressCallback
): Promise<void> {
  const isPortrait = layout.orientation === 'portrait';
  const doc = new jsPDF({
    orientation: isPortrait ? 'portrait' : 'landscape',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  const total = layout.positions.length;
  const outerW = layout.outerDiameterMm;
  const outerH = layout.outerSecondaryMm || outerW;
  const innerW = layout.innerDiameterMm;
  const innerH = layout.innerSecondaryMm || innerW;
  const radius = outerW / 2;
  const innerRadius = innerW / 2;

  for (let i = 0; i < total; i++) {
    const pos = layout.positions[i];
    if (onProgress) {
      onProgress(i + 1, total, `Processando botton ${i + 1} de ${total}...`);
    }

    const art = artworks[pos.index] || defaultArt;
    try {
      const btnCanvas = await renderButtonCanvas(
        art,
        layout,
        foilOptions,
        750
      );

      if (btnCanvas) {
        const imgData = btnCanvas.toDataURL('image/png');
        doc.addImage(
          imgData,
          'PNG',
          pos.x - outerW / 2,
          pos.y - outerH / 2,
          outerW,
          outerH,
          undefined,
          'FAST'
        );
      }
    } catch (err) {
      console.error('Erro ao renderizar imagem para PDF:', err);
    }

    // Draw Subtle Outer Cut Line
    if (cutLineOptions.showCutLine) {
      const hex = cutLineOptions.cutLineColor.replace('#', '');
      const r = parseInt(hex.substring(0, 2), 16) || 160;
      const g = parseInt(hex.substring(2, 4), 16) || 160;
      const b = parseInt(hex.substring(4, 6), 16) || 160;

      const opacity = Math.max(0.1, Math.min(1.0, cutLineOptions.cutLineOpacity));
      const blendedR = Math.round(r * opacity + 255 * (1 - opacity));
      const blendedG = Math.round(g * opacity + 255 * (1 - opacity));
      const blendedB = Math.round(b * opacity + 255 * (1 - opacity));

      doc.setDrawColor(blendedR, blendedG, blendedB);
      doc.setLineWidth(cutLineOptions.cutLineWidthMm || 0.2);

      if (cutLineOptions.cutLineStyle === 'dashed') {
        doc.setLineDashPattern([2, 1.5], 0);
      } else if (cutLineOptions.cutLineStyle === 'dotted') {
        doc.setLineDashPattern([0.5, 1], 0);
      } else {
        doc.setLineDashPattern([], 0);
      }

      if (layout.shape === 'round') {
        doc.circle(pos.x, pos.y, radius, 'S');
      } else if (layout.shape === 'square' || layout.shape === 'rectangle') {
        doc.roundedRect(pos.x - outerW / 2, pos.y - outerH / 2, outerW, outerH, 3, 3, 'S');
      } else {
        doc.circle(pos.x, pos.y, radius, 'S');
      }
    }

    // Optional Inner Guide (usually not printed)
    if (cutLineOptions.showInnerGuide && cutLineOptions.printInnerGuide) {
      doc.setDrawColor(200, 210, 225);
      doc.setLineWidth(0.15);
      doc.setLineDashPattern([1, 2], 0);

      if (layout.shape === 'round') {
        doc.circle(pos.x, pos.y, innerRadius, 'S');
      } else if (layout.shape === 'square' || layout.shape === 'rectangle') {
        doc.roundedRect(pos.x - innerW / 2, pos.y - innerH / 2, innerW, innerH, 2, 2, 'S');
      }
      doc.setLineDashPattern([], 0);
    }

    // Center Cross Marks
    if (cutLineOptions.showCenterMarks) {
      doc.setDrawColor(180, 180, 180);
      doc.setLineWidth(0.1);
      doc.setLineDashPattern([], 0);
      doc.line(pos.x - 1.5, pos.y, pos.x + 1.5, pos.y);
      doc.line(pos.x, pos.y - 1.5, pos.x, pos.y + 1.5);
    }
  }

  doc.setFontSize(7);
  doc.setTextColor(150, 150, 150);
  const metadataText = `ZavaPrint Bottons Pro • A4 • ${layout.shape.toUpperCase()} ${layout.innerDiameterMm}mm (Corte: ${outerW}mm) • Qtd: ${layout.totalPositions} unid • ${foilOptions.enabled ? 'MATRIZ FOIL LASER' : 'IMPRESSÃO'}`;
  doc.text(metadataText, 8, layout.pageHeightMm - 4);

  const filename = `zavaprint_bottons_${layout.shape}_${layout.innerDiameterMm}mm_${layout.totalPositions}unid.pdf`;
  doc.save(filename);
}

/**
 * Export 300 DPI high-resolution PNG image of the full A4 sheet
 */
export async function exportToPng(
  layout: LayoutCalculation,
  artworks: Record<number, BottonArtwork>,
  defaultArt: BottonArtwork | null,
  cutLineOptions: CutLineOptions,
  foilOptions: FoilMatrixOptions,
  onProgress?: ExportProgressCallback
): Promise<void> {
  const DPI = 300;
  const mmToPx = DPI / 25.4;

  const canvasWidth = Math.round(layout.pageWidthMm * mmToPx);
  const canvasHeight = Math.round(layout.pageHeightMm * mmToPx);

  const canvas = document.createElement('canvas');
  canvas.width = canvasWidth;
  canvas.height = canvasHeight;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvasWidth, canvasHeight);

  const total = layout.positions.length;
  const outerWPx = layout.outerDiameterMm * mmToPx;
  const outerHPx = (layout.outerSecondaryMm || layout.outerDiameterMm) * mmToPx;
  const innerWPx = layout.innerDiameterMm * mmToPx;
  const innerHPx = (layout.innerSecondaryMm || layout.innerDiameterMm) * mmToPx;

  for (let i = 0; i < total; i++) {
    const pos = layout.positions[i];
    if (onProgress) {
      onProgress(i + 1, total, `Gerando PNG: item ${i + 1} de ${total}...`);
    }

    const posX = pos.x * mmToPx;
    const posY = pos.y * mmToPx;

    const art = artworks[pos.index] || defaultArt;
    try {
      const btnCanvas = await renderButtonCanvas(
        art,
        layout,
        foilOptions,
        Math.round(outerWPx)
      );

      if (btnCanvas) {
        ctx.drawImage(
          btnCanvas,
          posX - outerWPx / 2,
          posY - outerHPx / 2,
          outerWPx,
          outerHPx
        );
      }
    } catch (err) {
      console.error('Erro ao renderizar imagem para PNG:', err);
    }

    // Outer Cut Line
    if (cutLineOptions.showCutLine) {
      ctx.save();
      ctx.strokeStyle = cutLineOptions.cutLineColor;
      ctx.globalAlpha = cutLineOptions.cutLineOpacity;
      ctx.lineWidth = Math.max(1, cutLineOptions.cutLineWidthMm * mmToPx);

      if (cutLineOptions.cutLineStyle === 'dashed') {
        ctx.setLineDash([8, 6]);
      } else if (cutLineOptions.cutLineStyle === 'dotted') {
        ctx.setLineDash([3, 4]);
      }

      drawShapePath(ctx, layout.shape, posX, posY, outerWPx, outerHPx, 8);
      ctx.stroke();
      ctx.restore();
    }

    // Optional Inner Guide
    if (cutLineOptions.showInnerGuide && cutLineOptions.printInnerGuide) {
      ctx.save();
      ctx.strokeStyle = '#94a3b8';
      ctx.globalAlpha = 0.4;
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 6]);
      drawShapePath(ctx, layout.shape, posX, posY, innerWPx, innerHPx, 6);
      ctx.stroke();
      ctx.restore();
    }
  }

  ctx.fillStyle = '#94a3b8';
  ctx.font = '24px "Plus Jakarta Sans", sans-serif';
  ctx.fillText(
    `ZavaPrint Bottons Pro • A4 • ${layout.shape.toUpperCase()} ${layout.innerDiameterMm}mm • ${total} unid • 300 DPI`,
    30,
    canvasHeight - 20
  );

  const dataUrl = canvas.toDataURL('image/png');
  const link = document.createElement('a');
  link.download = `zavaprint_bottons_${layout.shape}_${layout.innerDiameterMm}mm_${total}unid_300dpi.png`;
  link.href = dataUrl;
  link.click();
}
