import { FoilMatrixOptions } from '../types/button';

/**
 * Loads an image from a data URL or File
 */
export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = (e) => reject(new Error('Falha ao carregar imagem: ' + e));
    img.src = src;
  });
}

/**
 * Applies Foil Matrix Laser filtering to an image
 * Converts to 100% Black toner (K:100%) for thermal foil lamination
 */
export async function applyFoilFilter(
  sourceUrl: string,
  options: FoilMatrixOptions
): Promise<string> {
  if (!options.enabled) {
    return sourceUrl;
  }

  const img = await loadImage(sourceUrl);
  const canvas = document.createElement('canvas');
  canvas.width = img.naturalWidth || img.width;
  canvas.height = img.naturalHeight || img.height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  if (!ctx) return sourceUrl;

  ctx.drawImage(img, 0, 0);
  const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imgData.data;
  const threshold = options.threshold;
  const invert = options.invert;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const a = data[i + 3];

    // If pixel is mostly transparent, keep transparent
    if (a < 30) {
      data[i + 3] = 0;
      continue;
    }

    // Standard ITU-R BT.601 luminance
    const luminance = 0.299 * r + 0.587 * g + 0.114 * b;

    let isBlack = luminance < threshold;
    if (invert) {
      isBlack = !isBlack;
    }

    if (isBlack) {
      // Pure 100% Black Toner K
      data[i] = 0;
      data[i + 1] = 0;
      data[i + 2] = 0;
      data[i + 3] = 255;
    } else {
      // Pure White background (or transparent if desired)
      data[i] = 255;
      data[i + 1] = 255;
      data[i + 2] = 255;
      data[i + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);
  return canvas.toDataURL('image/png');
}

/**
 * Reads a File object and converts it to a base64 DataURL
 */
export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
