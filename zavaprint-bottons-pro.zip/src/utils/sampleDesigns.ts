import { BleedType } from '../types/button';

/**
 * Sample designs tailored for ZavaPrint and botton making
 */

export interface SampleBadge {
  id: string;
  name: string;
  category: string;
  dataUrl: string;
  defaultBleedType: BleedType;
  defaultBleedColor: string;
  defaultFaceBgColor: string;
}

function createBadgeCanvas(
  render: (ctx: CanvasRenderingContext2D, size: number) => void
): string {
  const size = 600;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  render(ctx, size);

  return canvas.toDataURL('image/png');
}

export function generateSampleBadges(): SampleBadge[] {
  const badges: SampleBadge[] = [];

  // 0. User's uploaded Bulma Artwork
  badges.push({
    id: 'sample-bulma',
    name: 'Bulma (Sua Imagem)',
    category: 'Sua Imagem',
    dataUrl: '/assets/aistudio/Bulma__01_22332b8f.jpg',
    defaultBleedType: 'image_continuous', // Sangria com a própria imagem contínua!
    defaultBleedColor: '#ef4444', // Vermelho como no print enviado
    defaultFaceBgColor: '#ffffff',
  });

  // 1. ZavaPrint Logo Emblem
  const zavaPrintLogo = createBadgeCanvas((ctx, size) => {
    const center = size / 2;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, size, size);

    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 14;
    ctx.strokeRect(center - 140, center - 140, 280, 280);

    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 6;
    ctx.strokeRect(center - 120, center - 120, 240, 240);

    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.moveTo(center - 60, center - 70);
    ctx.lineTo(center + 60, center - 70);
    ctx.lineTo(center + 60, center - 45);
    ctx.lineTo(center - 25, center + 40);
    ctx.lineTo(center + 60, center + 40);
    ctx.lineTo(center + 60, center + 65);
    ctx.lineTo(center - 60, center + 65);
    ctx.lineTo(center - 60, center + 40);
    ctx.lineTo(center + 25, center - 45);
    ctx.lineTo(center - 60, center - 45);
    ctx.closePath();
    ctx.fill();

    ctx.font = 'bold 34px "Plus Jakarta Sans", sans-serif';
    ctx.fillStyle = '#0f172a';
    ctx.textAlign = 'center';
    ctx.fillText('ZAVAPRINT', center, center + 185);

    ctx.font = '600 16px "Plus Jakarta Sans", sans-serif';
    ctx.fillStyle = '#f59e0b';
    ctx.fillText('FINE ART & QUADROS', center, center + 215);
  });

  // 2. Quadro de Arte Abstrata
  const abstractArt = createBadgeCanvas((ctx, size) => {
    const center = size / 2;
    const grad = ctx.createLinearGradient(0, 0, size, size);
    grad.addColorStop(0, '#fef3c7');
    grad.addColorStop(0.5, '#fde68a');
    grad.addColorStop(1, '#fed7aa');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);

    ctx.fillStyle = '#c2410c';
    ctx.beginPath();
    ctx.arc(center, center - 10, 130, Math.PI, 0);
    ctx.fill();

    ctx.fillStyle = '#15803d';
    ctx.beginPath();
    ctx.ellipse(center - 30, center + 50, 60, 110, -0.3, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(center + 50, center + 30, 45, 0, Math.PI * 2);
    ctx.fill();

    ctx.font = 'bold 28px "Plus Jakarta Sans", sans-serif';
    ctx.fillStyle = '#7c2d12';
    ctx.textAlign = 'center';
    ctx.fillText('GALERIA ZAVA', center, center + 175);
  });

  // 3. Cute Coffee Lover
  const coffeeBadge = createBadgeCanvas((ctx, size) => {
    const center = size / 2;
    ctx.fillStyle = '#451a03';
    ctx.fillRect(0, 0, size, size);

    ctx.fillStyle = '#fef3c7';
    ctx.beginPath();
    ctx.arc(center, center - 15, 120, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#78350f';
    ctx.beginPath();
    ctx.roundRect(center - 55, center - 40, 110, 80, [0, 0, 24, 24]);
    ctx.fill();

    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = 12;
    ctx.beginPath();
    ctx.arc(center + 60, center - 2, 20, -Math.PI / 2, Math.PI / 2);
    ctx.stroke();

    ctx.font = 'bold 30px "Plus Jakarta Sans", sans-serif';
    ctx.fillStyle = '#fef3c7';
    ctx.textAlign = 'center';
    ctx.fillText('COFFEE LOVER', center, center + 165);
  });

  // 4. Retro Wave Sunset
  const retroSunset = createBadgeCanvas((ctx, size) => {
    const center = size / 2;
    const grad = ctx.createLinearGradient(0, 0, 0, size);
    grad.addColorStop(0, '#0f172a');
    grad.addColorStop(0.5, '#4338ca');
    grad.addColorStop(0.85, '#ec4899');
    grad.addColorStop(1, '#f97316');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, size, size);

    ctx.fillStyle = '#fbbf24';
    ctx.beginPath();
    ctx.arc(center, center - 20, 130, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#4338ca';
    for (let y = center - 20; y < center + 110; y += 18) {
      const h = (y - (center - 20)) / 10 + 2;
      ctx.fillRect(center - 140, y, 280, h);
    }

    ctx.font = 'bold 34px "Plus Jakarta Sans", sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText('RETRO WAVE', center, center + 175);
  });

  // 5. Foil Geometric Sacred (Laser K:100%)
  const foilBadge = createBadgeCanvas((ctx, size) => {
    const center = size / 2;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, size, size);

    ctx.fillStyle = '#000000';
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 8;

    ctx.beginPath();
    ctx.arc(center, center, 130, 0, Math.PI * 2);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(center, center, 85, 0, Math.PI * 2);
    ctx.stroke();

    const points = 8;
    ctx.beginPath();
    for (let i = 0; i <= points; i++) {
      const angle = (i * 2 * Math.PI) / points;
      const x = center + Math.cos(angle) * 65;
      const y = center + Math.sin(angle) * 65;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    ctx.font = 'bold 30px "Plus Jakarta Sans", sans-serif';
    ctx.fillStyle = '#000000';
    ctx.textAlign = 'center';
    ctx.fillText('MATRIZ FOIL LASER', center, center + 170);
  });

  badges.push(
    {
      id: 'sample-zavaprint',
      name: 'ZavaPrint Quadros',
      category: 'ZavaPrint',
      dataUrl: zavaPrintLogo,
      defaultBleedType: 'solid_color',
      defaultBleedColor: '#0f172a',
      defaultFaceBgColor: '#ffffff',
    },
    {
      id: 'sample-abstract',
      name: 'Arte Abstrata Galeria',
      category: 'Colorido',
      dataUrl: abstractArt,
      defaultBleedType: 'image_continuous',
      defaultBleedColor: '#c2410c',
      defaultFaceBgColor: '#fef3c7',
    },
    {
      id: 'sample-coffee',
      name: 'Coffee Lover',
      category: 'Colorido',
      dataUrl: coffeeBadge,
      defaultBleedType: 'solid_color',
      defaultBleedColor: '#451a03',
      defaultFaceBgColor: '#fef3c7',
    },
    {
      id: 'sample-retro',
      name: 'Retro 80s Wave',
      category: 'Colorido',
      dataUrl: retroSunset,
      defaultBleedType: 'image_continuous',
      defaultBleedColor: '#0f172a',
      defaultFaceBgColor: '#0f172a',
    },
    {
      id: 'sample-foil',
      name: 'Matriz Foil Laser',
      category: 'Foil Laser',
      dataUrl: foilBadge,
      defaultBleedType: 'solid_color',
      defaultBleedColor: '#000000',
      defaultFaceBgColor: '#ffffff',
    }
  );

  return badges;
}
