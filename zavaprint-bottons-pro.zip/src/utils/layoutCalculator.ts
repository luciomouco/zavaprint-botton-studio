import {
  ButtonShape,
  CirclePositionMm,
  LayoutArrangement,
  LayoutCalculation,
  PageMarginsMm,
  PageOrientation,
} from '../types/button';

export const A4_WIDTH_MM = 210;
export const A4_HEIGHT_MM = 297;

export interface CalculateLayoutOptions {
  orientation: PageOrientation;
  shape: ButtonShape;
  outerDiameterMm: number;
  outerSecondaryMm?: number;
  innerDiameterMm: number;
  innerSecondaryMm?: number;
  margins: PageMarginsMm;
  gapMm: number;
  arrangement: LayoutArrangement;
  offsetX?: number;
  offsetY?: number;
  centerContent?: boolean;
}

export function calculateA4Layout(options: CalculateLayoutOptions): LayoutCalculation {
  const {
    orientation,
    shape,
    outerDiameterMm,
    outerSecondaryMm = outerDiameterMm,
    innerDiameterMm,
    innerSecondaryMm = innerDiameterMm,
    margins,
    gapMm,
    arrangement,
    offsetX = 0,
    offsetY = 0,
    centerContent = true,
  } = options;

  const pageWidthMm = orientation === 'portrait' ? A4_WIDTH_MM : A4_HEIGHT_MM;
  const pageHeightMm = orientation === 'portrait' ? A4_HEIGHT_MM : A4_WIDTH_MM;

  const availWidth = pageWidthMm - margins.left - margins.right;
  const availHeight = pageHeightMm - margins.top - margins.bottom;

  const positions: CirclePositionMm[] = [];
  const widthMm = outerDiameterMm;
  const heightMm = outerSecondaryMm;

  const pitchX = widthMm + gapMm;
  const pitchY = heightMm + gapMm;

  let cols = 0;
  let rows = 0;

  // Staggered arrangement is only optimal for round shapes
  const effectiveArrangement = shape === 'round' ? arrangement : 'grid';

  if (effectiveArrangement === 'grid') {
    cols = Math.max(1, Math.floor((availWidth + gapMm) / pitchX));
    rows = Math.max(1, Math.floor((availHeight + gapMm) / pitchY));

    const totalGridWidth = cols * widthMm + (cols - 1) * gapMm;
    const totalGridHeight = rows * heightMm + (rows - 1) * gapMm;

    const startX = centerContent
      ? margins.left + (availWidth - totalGridWidth) / 2 + widthMm / 2 + offsetX
      : margins.left + widthMm / 2 + offsetX;

    const startY = centerContent
      ? margins.top + (availHeight - totalGridHeight) / 2 + heightMm / 2 + offsetY
      : margins.top + heightMm / 2 + offsetY;

    let index = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const x = startX + c * pitchX;
        const y = startY + r * pitchY;

        if (
          x - widthMm / 2 >= 0 &&
          x + widthMm / 2 <= pageWidthMm &&
          y - heightMm / 2 >= 0 &&
          y + heightMm / 2 <= pageHeightMm
        ) {
          positions.push({
            index,
            row: r,
            col: c,
            x: Math.round(x * 100) / 100,
            y: Math.round(y * 100) / 100,
            widthMm,
            heightMm,
          });
          index++;
        }
      }
    }
  } else {
    // Hexagonal staggered packing for round items
    const staggeredPitchY = pitchX * 0.8660254; // sin(60°)
    rows = Math.max(1, Math.floor((availHeight - heightMm) / staggeredPitchY) + 1);
    cols = Math.max(1, Math.floor((availWidth + gapMm) / pitchX));

    const effectiveGridHeight = heightMm + (rows - 1) * staggeredPitchY;
    const startY = centerContent
      ? margins.top + (availHeight - effectiveGridHeight) / 2 + heightMm / 2 + offsetY
      : margins.top + heightMm / 2 + offsetY;

    let index = 0;
    for (let r = 0; r < rows; r++) {
      const isOddRow = r % 2 === 1;
      const rowOffset = isOddRow ? pitchX / 2 : 0;
      const rowCols = isOddRow
        ? Math.floor((availWidth - rowOffset + gapMm) / pitchX)
        : cols;

      const rowWidth = (rowCols - 1) * pitchX + widthMm;
      const startX = centerContent
        ? margins.left + (availWidth - rowWidth) / 2 + widthMm / 2 + (isOddRow ? rowOffset / 2 : 0) + offsetX
        : margins.left + widthMm / 2 + rowOffset + offsetX;

      for (let c = 0; c < rowCols; c++) {
        const x = startX + c * pitchX;
        const y = startY + r * staggeredPitchY;

        if (
          x - widthMm / 2 >= 0 &&
          x + widthMm / 2 <= pageWidthMm &&
          y - heightMm / 2 >= 0 &&
          y + heightMm / 2 <= pageHeightMm
        ) {
          positions.push({
            index,
            row: r,
            col: c,
            x: Math.round(x * 100) / 100,
            y: Math.round(y * 100) / 100,
            widthMm,
            heightMm,
          });
          index++;
        }
      }
    }
  }

  const singleArea =
    shape === 'round'
      ? Math.PI * Math.pow(widthMm / 2, 2)
      : widthMm * heightMm;

  const usedAreaMm2 = positions.length * singleArea;
  const totalPageAreaMm2 = pageWidthMm * pageHeightMm;
  const efficiencyPercent = Math.round((usedAreaMm2 / totalPageAreaMm2) * 100);

  return {
    orientation,
    pageWidthMm,
    pageHeightMm,
    outerDiameterMm: widthMm,
    outerSecondaryMm: heightMm,
    innerDiameterMm,
    innerSecondaryMm,
    shape,
    cols,
    rows,
    totalPositions: positions.length,
    positions,
    usedAreaMm2: Math.round(usedAreaMm2),
    totalPageAreaMm2: Math.round(totalPageAreaMm2),
    efficiencyPercent,
    marginEffective: margins,
    gapMm,
  };
}
