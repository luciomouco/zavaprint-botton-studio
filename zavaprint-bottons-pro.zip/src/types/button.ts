/**
 * Types and configurations for ZavaPrint Bottons Pro
 */

export type ButtonShape = 'round' | 'square' | 'rectangle' | 'heart';

export interface ButtonPreset {
  id: string;
  name: string;
  shape: ButtonShape;
  nominalSizeMm: number | string; // e.g. 32 or "60x40"
  innerDiameterMm: number; // Face diameter (e.g. 33mm)
  innerSecondaryMm?: number;
  outerDiameterMm: number; // Cut line diameter (e.g. 46mm)
  outerSecondaryMm?: number;
  cornerRadiusMm?: number;
  description: string;
  category: 'Redondo' | 'Quadrado' | 'Retângulo' | 'Coração' | 'Personalizado';
}

export const ALL_BUTTON_PRESETS: ButtonPreset[] = [
  // Redondos (Standard market sizes)
  {
    id: 'round-25mm',
    name: 'Redondo 25 mm',
    shape: 'round',
    nominalSizeMm: 25,
    innerDiameterMm: 25,
    outerDiameterMm: 35,
    category: 'Redondo',
    description: 'Mini botton clássico para mochilas e crachás.',
  },
  {
    id: 'round-32mm',
    name: 'Redondo 32 mm (Padrão)',
    shape: 'round',
    nominalSizeMm: 32,
    innerDiameterMm: 33, // 3.3 cm
    outerDiameterMm: 46, // 4.6 cm
    category: 'Redondo',
    description: 'Padrão mais vendido: Face 33 mm com sangria/corte de 46 mm.',
  },
  {
    id: 'round-38mm',
    name: 'Redondo 38 mm',
    shape: 'round',
    nominalSizeMm: 38,
    innerDiameterMm: 38,
    outerDiameterMm: 49,
    category: 'Redondo',
    description: 'Tamanho intermediário ideal para broches corporativos.',
  },
  {
    id: 'round-44mm',
    name: 'Redondo 44 mm (Padrão)',
    shape: 'round',
    nominalSizeMm: 44,
    innerDiameterMm: 44, // 4.4 cm
    outerDiameterMm: 55, // 5.5 cm
    category: 'Redondo',
    description: 'Padrão médio: Face 44 mm com sangria/corte de 55 mm.',
  },
  {
    id: 'round-55mm',
    name: 'Redondo 55 mm',
    shape: 'round',
    nominalSizeMm: 55,
    innerDiameterMm: 55,
    outerDiameterMm: 66,
    category: 'Redondo',
    description: 'Excelente para fotos de eventos e datas comemorativas.',
  },
  {
    id: 'round-58mm',
    name: 'Redondo 58 mm (Padrão)',
    shape: 'round',
    nominalSizeMm: 58,
    innerDiameterMm: 58, // 5.8 cm
    outerDiameterMm: 70, // 7.0 cm
    category: 'Redondo',
    description: 'Padrão grande: Face 58 mm com sangria/corte de 70 mm.',
  },
  {
    id: 'round-65mm',
    name: 'Redondo 65 mm',
    shape: 'round',
    nominalSizeMm: 65,
    innerDiameterMm: 65,
    outerDiameterMm: 78,
    category: 'Redondo',
    description: 'Botton espelho ou abridor de garrafas grande.',
  },
  {
    id: 'round-75mm',
    name: 'Redondo 75 mm',
    shape: 'round',
    nominalSizeMm: 75,
    innerDiameterMm: 75,
    outerDiameterMm: 86,
    category: 'Redondo',
    description: 'Grande destaque para medalhas, espelhos de bolsa e campanhas.',
  },

  // Quadrados
  {
    id: 'square-37mm',
    name: 'Quadrado 37 × 37 mm',
    shape: 'square',
    nominalSizeMm: 37,
    innerDiameterMm: 37,
    outerDiameterMm: 48,
    cornerRadiusMm: 4,
    category: 'Quadrado',
    description: 'Botton quadrado elegante para logos e arte geométrica.',
  },
  {
    id: 'square-50mm',
    name: 'Quadrado 50 × 50 mm',
    shape: 'square',
    nominalSizeMm: 50,
    innerDiameterMm: 50,
    outerDiameterMm: 62,
    cornerRadiusMm: 5,
    category: 'Quadrado',
    description: 'Botton quadrado grande com cantos arredondados.',
  },

  // Retângulos
  {
    id: 'rect-60x40mm',
    name: 'Retângulo 60 × 40 mm',
    shape: 'rectangle',
    nominalSizeMm: '60x40',
    innerDiameterMm: 60,
    innerSecondaryMm: 40,
    outerDiameterMm: 72,
    outerSecondaryMm: 52,
    cornerRadiusMm: 5,
    category: 'Retângulo',
    description: 'Formato crachá horizontal ou ímã de geladeira.',
  },
  {
    id: 'rect-70x25mm',
    name: 'Retângulo 70 × 25 mm',
    shape: 'rectangle',
    nominalSizeMm: '70x25',
    innerDiameterMm: 70,
    innerSecondaryMm: 25,
    outerDiameterMm: 82,
    outerSecondaryMm: 37,
    cornerRadiusMm: 4,
    category: 'Retângulo',
    description: 'Formato crachá de identificação de nome e cargo.',
  },

  // Coração
  {
    id: 'heart-52x57mm',
    name: 'Coração 52 × 57 mm',
    shape: 'heart',
    nominalSizeMm: '52x57',
    innerDiameterMm: 52,
    innerSecondaryMm: 57,
    outerDiameterMm: 64,
    outerSecondaryMm: 69,
    category: 'Coração',
    description: 'Formato romântico exclusivo para lembrancinhas e casamentos.',
  },
];

/**
 * Bleed options requested by user:
 * - 'image_continuous': Uses the image itself as bleed (extends naturally past the inner face to cut line)
 * - 'image_mirror': Mirrors the image edges outward into the bleed rim
 * - 'image_blur': Expanded blurred version of the image in the bleed rim
 * - 'solid_color': Confines art to face and uses solid color in bleed rim (like the red ring in screenshot)
 */
export type BleedType =
  | 'image_continuous'
  | 'image_mirror'
  | 'image_blur'
  | 'solid_color';

export type PageOrientation = 'portrait' | 'landscape';
export type LayoutArrangement = 'grid' | 'staggered';

export interface PageMarginsMm {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

export interface CutLineOptions {
  showCutLine: boolean;
  cutLineColor: string;
  cutLineOpacity: number;
  cutLineWidthMm: number;
  cutLineStyle: 'solid' | 'dashed' | 'dotted';
  showInnerGuide: boolean;
  innerGuideColor: string;
  innerGuideOpacity: number;
  innerGuideStyle: 'dashed' | 'dotted' | 'solid';
  printInnerGuide: boolean;
  showCenterMarks: boolean;
  showCornerCropMarks: boolean;
}

export interface FoilMatrixOptions {
  enabled: boolean;
  threshold: number;
  invert: boolean;
  highContrast: boolean;
}

export interface BottonArtwork {
  id: string;
  name: string;
  dataUrl: string;
  scale: number;
  panX: number;
  panY: number;
  rotation: number;
  // Bleed type: Própria imagem contínua, espelhada, desfocada ou cor sólida
  bleedType: BleedType;
  bleedColor: string; // Cor usada quando bleedType === 'solid_color'
  faceBgColor: string; // Cor de fundo se imagem tiver transparência
  rimText?: string;
  rimTextColor?: string;
}

export interface CirclePositionMm {
  index: number;
  row: number;
  col: number;
  x: number;
  y: number;
  widthMm: number;
  heightMm: number;
}

export interface LayoutCalculation {
  orientation: PageOrientation;
  pageWidthMm: number;
  pageHeightMm: number;
  outerDiameterMm: number;
  outerSecondaryMm?: number;
  innerDiameterMm: number;
  innerSecondaryMm?: number;
  shape: ButtonShape;
  cols: number;
  rows: number;
  totalPositions: number;
  positions: CirclePositionMm[];
  usedAreaMm2: number;
  totalPageAreaMm2: number;
  efficiencyPercent: number;
  marginEffective: PageMarginsMm;
  gapMm: number;
}
