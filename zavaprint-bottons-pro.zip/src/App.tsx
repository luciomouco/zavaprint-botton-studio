import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  ALL_BUTTON_PRESETS,
  ButtonPreset,
  CutLineOptions,
  FoilMatrixOptions,
  LayoutArrangement,
  PageMarginsMm,
  PageOrientation,
  BottonArtwork,
} from './types/button';
import { calculateA4Layout } from './utils/layoutCalculator';
import { generateSampleBadges, SampleBadge } from './utils/sampleDesigns';
import { readFileAsDataUrl } from './utils/imageProcessing';
import { exportToPdf, exportToPng } from './utils/exportUtils';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { A4Workspace } from './components/A4Workspace';
import { SlotInspectorModal } from './components/SlotInspectorModal';
import { PrintPreviewModal } from './components/PrintPreviewModal';
import { ResetConfirmModal } from './components/ResetConfirmModal';

export default function App() {
  // Default preset is standard 32mm (Face 33mm, Corte 46mm)
  const defaultPreset = ALL_BUTTON_PRESETS.find((p) => p.id === 'round-32mm') || ALL_BUTTON_PRESETS[1];
  const [currentPreset, setCurrentPreset] = useState<ButtonPreset>(defaultPreset);
  const [customInnerMm, setCustomInnerMm] = useState<number>(33);
  const [customOuterMm, setCustomOuterMm] = useState<number>(46);

  // Sheet layout settings
  const [orientation, setOrientation] = useState<PageOrientation>('portrait');
  const [arrangement, setArrangement] = useState<LayoutArrangement>('grid');
  const [margins, setMargins] = useState<PageMarginsMm>({ top: 8, right: 8, bottom: 8, left: 8 });
  const [gapMm, setGapMm] = useState<number>(1.5);
  const [offsetX, setOffsetX] = useState<number>(0);
  const [offsetY, setOffsetY] = useState<number>(0);

  // Cut line & Guides
  const [cutLineOptions, setCutLineOptions] = useState<CutLineOptions>({
    showCutLine: true,
    cutLineColor: '#94a3b8',
    cutLineOpacity: 0.35,
    cutLineWidthMm: 0.25,
    cutLineStyle: 'solid',
    showInnerGuide: true,
    innerGuideColor: '#3b82f6',
    innerGuideOpacity: 0.45,
    innerGuideStyle: 'dashed',
    printInnerGuide: false,
    showCenterMarks: false,
    showCornerCropMarks: true,
  });

  // Laser Foil Matrix Mode
  const [foilOptions, setFoilOptions] = useState<FoilMatrixOptions>({
    enabled: false,
    threshold: 128,
    invert: false,
    highContrast: true,
  });

  // Default state: Completely clean, no images loaded!
  const [defaultArt, setDefaultArt] = useState<BottonArtwork | null>({
    id: 'blank',
    name: '',
    dataUrl: '', // Clean empty template
    scale: 1.0,
    panX: 0,
    panY: 0,
    rotation: 0,
    bleedType: 'image_continuous',
    bleedColor: '#ffffff',
    faceBgColor: '#ffffff',
    rimText: '',
  });

  const [artworks, setArtworks] = useState<Record<number, BottonArtwork>>({});
  const [sampleBadges, setSampleBadges] = useState<SampleBadge[]>([]);

  // Modals & UI states
  const [selectedSlotIndex, setSelectedSlotIndex] = useState<number | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState<boolean>(false);
  const [isResetModalOpen, setIsResetModalOpen] = useState<boolean>(false);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportProgressText, setExportProgressText] = useState<string>('');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);

  // Load sample badge models on mount (for optional quick test in the sidebar, without applying to the sheet)
  useEffect(() => {
    const samples = generateSampleBadges();
    setSampleBadges(samples);
  }, []);

  // Calculate layout memoized
  const layout = useMemo(() => {
    return calculateA4Layout({
      orientation,
      shape: currentPreset.shape,
      outerDiameterMm: currentPreset.outerDiameterMm,
      outerSecondaryMm: currentPreset.outerSecondaryMm,
      innerDiameterMm: currentPreset.innerDiameterMm,
      innerSecondaryMm: currentPreset.innerSecondaryMm,
      margins,
      gapMm,
      arrangement,
      offsetX,
      offsetY,
      centerContent: true,
    });
  }, [
    orientation,
    currentPreset,
    margins,
    gapMm,
    arrangement,
    offsetX,
    offsetY,
  ]);

  // Reset to clean blank default project
  const handleResetToDefault = useCallback(() => {
    setCurrentPreset(defaultPreset);
    setCustomInnerMm(33);
    setCustomOuterMm(46);
    setOrientation('portrait');
    setArrangement('grid');
    setMargins({ top: 8, right: 8, bottom: 8, left: 8 });
    setGapMm(1.5);
    setOffsetX(0);
    setOffsetY(0);
    setCutLineOptions({
      showCutLine: true,
      cutLineColor: '#94a3b8',
      cutLineOpacity: 0.35,
      cutLineWidthMm: 0.25,
      cutLineStyle: 'solid',
      showInnerGuide: true,
      innerGuideColor: '#3b82f6',
      innerGuideOpacity: 0.45,
      innerGuideStyle: 'dashed',
      printInnerGuide: false,
      showCenterMarks: false,
      showCornerCropMarks: true,
    });
    setFoilOptions({
      enabled: false,
      threshold: 128,
      invert: false,
      highContrast: true,
    });
    setArtworks({});
    setSelectedSlotIndex(null);

    // Completely empty template, ready for a new project
    setDefaultArt({
      id: 'blank-' + Date.now(),
      name: '',
      dataUrl: '', // Empty
      scale: 1.0,
      panX: 0,
      panY: 0,
      rotation: 0,
      bleedType: 'image_continuous',
      bleedColor: '#ffffff',
      faceBgColor: '#ffffff',
      rimText: '',
    });
  }, [defaultPreset]);

  const handleSelectPreset = (preset: ButtonPreset) => {
    setCurrentPreset(preset);
  };

  const handleChangeCustomDimensions = (inner: number, outer: number) => {
    setCustomInnerMm(inner);
    setCustomOuterMm(outer);
    if (currentPreset.id === 'custom') {
      setCurrentPreset({
        id: 'custom',
        name: 'Tamanho Personalizado',
        shape: 'round',
        nominalSizeMm: inner,
        innerDiameterMm: inner,
        outerDiameterMm: outer,
        category: 'Personalizado',
        description: 'Medidas manuais de face e sangria.',
      });
    }
  };

  const handleUpdateDefaultArt = (updated: Partial<BottonArtwork>) => {
    setDefaultArt((prev) => (prev ? { ...prev, ...updated } : null));
    setArtworks((prev) => {
      const next: Record<number, BottonArtwork> = {};
      Object.keys(prev).forEach((key) => {
        const idx = Number(key);
        next[idx] = {
          ...prev[idx],
          ...updated,
        };
      });
      return next;
    });
  };

  const handleUploadImage = async (file: File, applyToAll: boolean) => {
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const newArt: BottonArtwork = {
        id: 'upload-' + Date.now(),
        name: file.name,
        dataUrl,
        scale: 1.0,
        panX: 0,
        panY: 0,
        rotation: 0,
        bleedType: defaultArt?.bleedType || 'image_continuous',
        bleedColor: defaultArt?.bleedColor || '#ffffff',
        faceBgColor: defaultArt?.faceBgColor || '#ffffff',
        rimText: defaultArt?.rimText,
      };

      if (applyToAll) {
        setDefaultArt(newArt);
        setArtworks({});
      } else if (selectedSlotIndex !== null) {
        setArtworks((prev) => ({
          ...prev,
          [selectedSlotIndex]: newArt,
        }));
      }
    } catch (err) {
      console.error('Erro ao ler arquivo:', err);
    }
  };

  const handleSelectSample = (badge: SampleBadge, applyToAll: boolean) => {
    const newArt: BottonArtwork = {
      id: badge.id,
      name: badge.name,
      dataUrl: badge.dataUrl,
      scale: 1.0,
      panX: 0,
      panY: 0,
      rotation: 0,
      bleedType: badge.defaultBleedType,
      bleedColor: badge.defaultBleedColor,
      faceBgColor: badge.defaultFaceBgColor,
      rimText: '',
    };

    if (applyToAll) {
      setDefaultArt(newArt);
      setArtworks({});
    } else if (selectedSlotIndex !== null) {
      setArtworks((prev) => ({
        ...prev,
        [selectedSlotIndex]: newArt,
      }));
    }
  };

  const handleApplyDefaultToAll = () => {
    setArtworks({});
  };

  const handleClearArtworks = () => {
    if (defaultArt) {
      setDefaultArt({
        ...defaultArt,
        dataUrl: '',
      });
    }
    setArtworks({});
  };

  const handleUpdateArtwork = (index: number, updated: Partial<BottonArtwork>) => {
    const existing = artworks[index] || defaultArt;
    if (!existing) return;

    setArtworks((prev) => ({
      ...prev,
      [index]: {
        ...existing,
        ...updated,
      },
    }));
  };

  const handleApplyToAll = (index: number) => {
    const art = artworks[index] || defaultArt;
    if (art) {
      setDefaultArt({ ...art });
      setArtworks({});
    }
    setSelectedSlotIndex(null);
  };

  const handleDuplicateSlotToAll = (index: number) => {
    const art = artworks[index] || defaultArt;
    if (art) {
      setDefaultArt({ ...art });
      setArtworks({});
    }
  };

  const handleClearSlot = (index: number) => {
    setArtworks((prev) => ({
      ...prev,
      [index]: {
        id: 'empty-' + index,
        name: 'Vazio',
        dataUrl: '',
        scale: 1,
        panX: 0,
        panY: 0,
        rotation: 0,
        bleedType: defaultArt?.bleedType || 'image_continuous',
        bleedColor: defaultArt?.bleedColor || '#ffffff',
        faceBgColor: defaultArt?.faceBgColor || '#ffffff',
      },
    }));
  };

  const handleRotateSlot = (index: number) => {
    const current = artworks[index] || defaultArt;
    if (!current) return;
    const nextRot = ((current.rotation || 0) + 90) % 360;
    handleUpdateArtwork(index, { rotation: nextRot });
  };

  const handleUploadSpecificImage = async (index: number, file: File) => {
    try {
      const dataUrl = await readFileAsDataUrl(file);
      const existing = artworks[index] || defaultArt;
      const newArt: BottonArtwork = {
        id: 'slot-' + index + '-' + Date.now(),
        name: file.name,
        dataUrl,
        scale: 1.0,
        panX: 0,
        panY: 0,
        rotation: 0,
        bleedType: existing?.bleedType || 'image_continuous',
        bleedColor: existing?.bleedColor || '#ffffff',
        faceBgColor: existing?.faceBgColor || '#ffffff',
        rimText: existing?.rimText,
      };
      setArtworks((prev) => ({
        ...prev,
        [index]: newArt,
      }));
    } catch (err) {
      console.error('Erro ao ler imagem individual:', err);
    }
  };

  // Export PDF
  const handleExportPdf = async () => {
    try {
      setIsExporting(true);
      setExportProgressText('Gerando PDF vetorial sem escala...');
      await exportToPdf(
        layout,
        artworks,
        defaultArt,
        cutLineOptions,
        foilOptions,
        (curr, total, msg) => {
          setExportProgressText(msg);
        }
      );
    } catch (err) {
      console.error('Falha ao exportar PDF:', err);
    } finally {
      setIsExporting(false);
      setExportProgressText('');
    }
  };

  // Export PNG
  const handleExportPng = async () => {
    try {
      setIsExporting(true);
      setExportProgressText('Renderizando folha em 300 DPI...');
      await exportToPng(
        layout,
        artworks,
        defaultArt,
        cutLineOptions,
        foilOptions,
        (curr, total, msg) => {
          setExportProgressText(msg);
        }
      );
    } catch (err) {
      console.error('Falha ao exportar PNG:', err);
    } finally {
      setIsExporting(false);
      setExportProgressText('');
    }
  };

  const handlePrintDirectly = () => {
    window.print();
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-100 font-sans antialiased text-slate-900">
      {/* Top Bar with brand "ZavaPrint - Botton Studio" and "Novo Projeto" */}
      <Header
        currentPreset={currentPreset}
        layout={layout}
        isFoilMode={foilOptions.enabled}
        onOpenPreview={() => setIsPreviewOpen(true)}
        onExportPdf={handleExportPdf}
        onExportPng={handleExportPng}
        onPrintDirectly={handlePrintDirectly}
        onResetProject={() => setIsResetModalOpen(true)}
        isExporting={isExporting}
        exportProgressText={exportProgressText}
        isSidebarOpen={isSidebarOpen}
        onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
      />

      {/* Main Split View */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Sidebar */}
        <Sidebar
          currentPreset={currentPreset}
          onSelectPreset={handleSelectPreset}
          orientation={orientation}
          onChangeOrientation={setOrientation}
          arrangement={arrangement}
          onChangeArrangement={setArrangement}
          margins={margins}
          onChangeMargins={setMargins}
          gapMm={gapMm}
          onChangeGapMm={setGapMm}
          offsetX={offsetX}
          offsetY={offsetY}
          onChangeOffsets={(x, y) => {
            setOffsetX(x);
            setOffsetY(y);
          }}
          cutLineOptions={cutLineOptions}
          onChangeCutLineOptions={setCutLineOptions}
          foilOptions={foilOptions}
          onChangeFoilOptions={setFoilOptions}
          layout={layout}
          defaultArt={defaultArt}
          onUpdateDefaultArt={handleUpdateDefaultArt}
          onUploadImage={handleUploadImage}
          sampleBadges={sampleBadges}
          onSelectSample={handleSelectSample}
          onClearArtworks={handleClearArtworks}
          onApplyDefaultToAll={handleApplyDefaultToAll}
          onResetProject={() => setIsResetModalOpen(true)}
          customInnerMm={customInnerMm}
          customOuterMm={customOuterMm}
          onChangeCustomDimensions={handleChangeCustomDimensions}
          isOpen={isSidebarOpen}
          onCloseMobile={() => setIsSidebarOpen(false)}
        />

        {/* Center Workspace */}
        <A4Workspace
          layout={layout}
          artworks={artworks}
          defaultArt={defaultArt}
          cutLineOptions={cutLineOptions}
          foilOptions={foilOptions}
          selectedSlotIndex={selectedSlotIndex}
          onSelectSlot={(index) => setSelectedSlotIndex(index)}
          onDuplicateSlotToAll={handleDuplicateSlotToAll}
          onClearSlot={handleClearSlot}
          onRotateSlot={handleRotateSlot}
          onUploadImage={handleUploadImage}
        />
      </div>

      {/* Slot Inspector Modal */}
      {selectedSlotIndex !== null && (
        <SlotInspectorModal
          slotIndex={selectedSlotIndex}
          artwork={artworks[selectedSlotIndex]}
          defaultArt={defaultArt}
          preset={currentPreset}
          onClose={() => setSelectedSlotIndex(null)}
          onUpdateArtwork={handleUpdateArtwork}
          onApplyToAll={handleApplyToAll}
          onUploadSpecificImage={handleUploadSpecificImage}
        />
      )}

      {/* Pre-Print Preview Modal */}
      {isPreviewOpen && (
        <PrintPreviewModal
          preset={currentPreset}
          layout={layout}
          artworks={artworks}
          defaultArt={defaultArt}
          margins={margins}
          onChangeMargins={setMargins}
          cutLineOptions={cutLineOptions}
          foilOptions={foilOptions}
          onClose={() => setIsPreviewOpen(false)}
          onExportPdf={handleExportPdf}
          onExportPng={handleExportPng}
          onPrintDirectly={handlePrintDirectly}
          isExporting={isExporting}
        />
      )}

      {/* Reset Confirmation Modal */}
      <ResetConfirmModal
        isOpen={isResetModalOpen}
        onClose={() => setIsResetModalOpen(false)}
        onConfirm={handleResetToDefault}
      />
    </div>
  );
}
