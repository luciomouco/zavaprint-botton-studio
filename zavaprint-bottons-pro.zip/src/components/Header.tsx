import React from 'react';
import {
  Printer,
  FileDown,
  Eye,
  Sparkles,
  Layers,
  Image as ImageIcon,
  RotateCcw,
  Menu,
  X
} from 'lucide-react';
import { ButtonPreset, LayoutCalculation } from '../types/button';

interface HeaderProps {
  currentPreset: ButtonPreset;
  layout: LayoutCalculation;
  isFoilMode: boolean;
  onOpenPreview: () => void;
  onExportPdf: () => void;
  onExportPng: () => void;
  onPrintDirectly: () => void;
  onResetProject: () => void;
  isExporting: boolean;
  exportProgressText?: string;
  isSidebarOpen: boolean;
  onToggleSidebar: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPreset,
  layout,
  isFoilMode,
  onOpenPreview,
  onExportPdf,
  onExportPng,
  onPrintDirectly,
  onResetProject,
  isExporting,
  exportProgressText,
  isSidebarOpen,
  onToggleSidebar,
}) => {
  return (
    <header className="no-print bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4 shrink-0 z-30 transition-all">
      {/* Zone 1: Brand & Context */}
      <div className="flex items-center gap-3 shrink-0">
        {/* Mobile Sidebar Toggle Button */}
        <button
          type="button"
          onClick={onToggleSidebar}
          className="lg:hidden p-1.5 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
          title={isSidebarOpen ? 'Recolher painel' : 'Abrir configurações'}
        >
          {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        {/* Brand Wordmark: "ZavaPrint - Botton Studio" */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-slate-900 text-amber-400 flex items-center justify-center font-bold text-xs tracking-tight shadow-xs border border-amber-500/20">
            ZP
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-bold tracking-tight text-slate-900 whitespace-nowrap">
                ZavaPrint <span className="font-light text-slate-400">|</span> <span className="text-indigo-600 font-semibold">Botton Studio</span>
              </span>
            </div>
            <p className="text-[10px] text-slate-500 font-medium hidden sm:block">
              Diagramação & Impressão A4
            </p>
          </div>
        </div>

        {/* Clean Unboxed Metadata (Zero-pill discipline) */}
        <div className="hidden xl:flex items-center gap-2 pl-3 border-l border-slate-200 text-xs text-slate-500">
          <span className="font-semibold text-slate-800">{currentPreset.name}</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>Face {currentPreset.innerDiameterMm} mm</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>Corte {currentPreset.outerDiameterMm} mm</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span className="font-semibold text-indigo-700 bg-indigo-50/80 px-2 py-0.5 rounded">
            {layout.totalPositions} por folha
          </span>
          {isFoilMode && (
            <>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span className="font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-600" />
                Foil Laser
              </span>
            </>
          )}
        </div>
      </div>

      {/* Zone 2: Sheet Status & Efficiency */}
      <div className="hidden md:flex items-center gap-3 text-xs text-slate-500">
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-50 border border-slate-200/80 rounded-md">
          <Layers className="w-3.5 h-3.5 text-slate-400" />
          <span>Aproveitamento:</span>
          <span className="font-semibold text-slate-900 font-mono">
            {layout.efficiencyPercent}% da folha
          </span>
        </div>
        {exportProgressText && (
          <span className="text-xs text-indigo-600 font-medium animate-pulse">
            {exportProgressText}
          </span>
        )}
      </div>

      {/* Zone 3: Actions */}
      <div className="flex items-center gap-2 shrink-0">
        {/* REQUESTED RESET / NEW PROJECT BUTTON */}
        <button
          onClick={onResetProject}
          type="button"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-indigo-700 bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 rounded-lg transition-colors cursor-pointer shadow-2xs"
          title="Zerar e recomeçar um novo projeto com configurações padrão"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-500 hover:text-indigo-600" />
          <span className="hidden sm:inline">Novo Projeto</span>
        </button>

        <button
          onClick={onOpenPreview}
          type="button"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200/80 rounded-lg transition-colors cursor-pointer"
          title="Visualizar a folha de impressão e testar margens"
        >
          <Eye className="w-3.5 h-3.5 text-slate-600" />
          <span className="hidden md:inline">Visualizar Impressão</span>
        </button>

        <button
          onClick={onExportPng}
          disabled={isExporting}
          type="button"
          className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200/80 rounded-lg transition-colors disabled:opacity-50 cursor-pointer"
          title="Baixar imagem A4 em alta resolução 300 DPI"
        >
          <ImageIcon className="w-3.5 h-3.5 text-slate-600" />
          <span>PNG 300 DPI</span>
        </button>

        <button
          onClick={onExportPdf}
          disabled={isExporting}
          type="button"
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-xs disabled:opacity-50 cursor-pointer"
          title="Exportar PDF pronto para impressão sem escala"
        >
          <FileDown className="w-3.5 h-3.5 text-amber-400" />
          <span>Exportar PDF</span>
        </button>

        <button
          onClick={onPrintDirectly}
          type="button"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer shadow-2xs"
          title="Imprimir direto (Escala 100% no navegador)"
        >
          <Printer className="w-3.5 h-3.5 text-slate-700" />
          <span className="hidden sm:inline">Imprimir</span>
        </button>
      </div>
    </header>
  );
};
