import React, { useState } from 'react';
import {
  X,
  Printer,
  FileDown,
  Image as ImageIcon,
  Sliders,
  CheckCircle2,
  Disc,
  ShieldCheck,
  Upload
} from 'lucide-react';
import {
  BleedType,
  BottonArtwork,
  ButtonPreset,
  CutLineOptions,
  FoilMatrixOptions,
  LayoutCalculation,
  PageMarginsMm,
} from '../types/button';

interface PrintPreviewModalProps {
  preset: ButtonPreset;
  layout: LayoutCalculation;
  artworks: Record<number, BottonArtwork>;
  defaultArt: BottonArtwork | null;
  margins: PageMarginsMm;
  onChangeMargins: (margins: PageMarginsMm) => void;
  cutLineOptions: CutLineOptions;
  foilOptions: FoilMatrixOptions;
  onClose: () => void;
  onExportPdf: () => void;
  onExportPng: () => void;
  onPrintDirectly: () => void;
  isExporting: boolean;
}

export const PrintPreviewModal: React.FC<PrintPreviewModalProps> = ({
  preset,
  layout,
  artworks,
  defaultArt,
  margins,
  onChangeMargins,
  cutLineOptions,
  foilOptions,
  onClose,
  onExportPdf,
  onExportPng,
  onPrintDirectly,
  isExporting,
}) => {
  const [viewMode, setViewMode] = useState<'sheet' | 'simulation'>('sheet');

  const representativeArt = artworks[0] || defaultArt;
  const hasImage = Boolean(representativeArt && representativeArt.dataUrl);
  const bleedType: BleedType = representativeArt?.bleedType || 'image_continuous';
  const bleedColor = representativeArt?.bleedColor || '#ef4444';
  const faceBgColor = representativeArt?.faceBgColor || '#ffffff';

  const shape = layout.shape;
  const borderRadius =
    shape === 'round' ? '9999px' : shape === 'heart' ? '0' : '6px';

  return (
    <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 lg:p-6 z-50 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200/90 w-full max-w-6xl h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-5 py-3 border-b border-slate-200/80 flex items-center justify-between bg-slate-50/80 shrink-0">
          <div className="flex items-center gap-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Visualização Pré-Impressão A4 • ZavaPrint
              </h2>
              <p className="text-[11px] text-slate-500">
                Ajuste as margens e confira a folha A4 antes de imprimir.
              </p>
            </div>

            {/* View Mode Toggle */}
            <div className="hidden sm:flex items-center p-1 bg-slate-200/70 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => setViewMode('sheet')}
                className={`px-3 py-1 font-semibold rounded-lg transition-colors cursor-pointer ${
                  viewMode === 'sheet'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Folha A4 Completa
              </button>
              <button
                type="button"
                onClick={() => setViewMode('simulation')}
                className={`px-3 py-1 font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1 ${
                  viewMode === 'simulation'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Disc className="w-3.5 h-3.5 text-indigo-600" />
                Simulação 3D
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onPrintDirectly}
              type="button"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Imprimir (100%)</span>
            </button>

            <button
              onClick={onExportPdf}
              disabled={isExporting}
              type="button"
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs cursor-pointer"
            >
              <FileDown className="w-3.5 h-3.5 text-amber-400" />
              <span>Baixar PDF</span>
            </button>

            <button
              onClick={onClose}
              type="button"
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 cursor-pointer ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Main Viewport */}
          <div className="flex-1 bg-slate-100/90 overflow-auto p-6 flex items-center justify-center relative">
            {viewMode === 'sheet' ? (
              /* A4 Sheet View */
              <div
                className="bg-white shadow-2xl relative border border-slate-300 transition-all duration-150"
                style={{
                  width: `${layout.pageWidthMm * 2.2}px`,
                  height: `${layout.pageHeightMm * 2.2}px`,
                }}
              >
                {/* Safe Margins */}
                <div
                  className="absolute pointer-events-none border border-dashed border-red-300"
                  style={{
                    top: `${layout.marginEffective.top * 2.2}px`,
                    left: `${layout.marginEffective.left * 2.2}px`,
                    right: `${layout.marginEffective.right * 2.2}px`,
                    bottom: `${layout.marginEffective.bottom * 2.2}px`,
                  }}
                >
                  <span className="absolute -top-3.5 left-1 text-[8px] font-mono text-red-500 font-bold bg-white/95 px-1 rounded">
                    Margem Imprimível
                  </span>
                </div>

                {/* Items */}
                {layout.positions.map((pos) => {
                  const art = artworks[pos.index] || defaultArt;
                  const itemOuterW = layout.outerDiameterMm * 2.2;
                  const itemOuterH = (layout.outerSecondaryMm || layout.outerDiameterMm) * 2.2;
                  const itemInnerW = layout.innerDiameterMm * 2.2;
                  const itemInnerH = (layout.innerSecondaryMm || layout.innerDiameterMm) * 2.2;

                  const centerXPx = pos.x * 2.2;
                  const posYPx = pos.y * 2.2;

                  const itemBleedType: BleedType = art?.bleedType || 'image_continuous';
                  const itemBleedColor = art?.bleedColor || '#ef4444';
                  const itemFaceBg = art?.faceBgColor || '#ffffff';
                  const itemHasImage = Boolean(art && art.dataUrl);

                  const imageTransform = `scale(${art?.scale || 1}) translate(${
                    ((art?.panX || 0) / layout.outerDiameterMm) * 100
                  }%, ${
                    ((art?.panY || 0) / (layout.outerSecondaryMm || layout.outerDiameterMm)) * 100
                  }%) rotate(${art?.rotation || 0}deg)`;

                  return (
                    <div
                      key={pos.index}
                      className="absolute overflow-hidden flex items-center justify-center shadow-2xs"
                      style={{
                        width: `${itemOuterW}px`,
                        height: `${itemOuterH}px`,
                        left: `${centerXPx - itemOuterW / 2}px`,
                        top: `${posYPx - itemOuterH / 2}px`,
                        backgroundColor: itemHasImage
                          ? itemBleedType === 'solid_color'
                            ? itemBleedColor
                            : itemFaceBg || '#ffffff'
                          : '#ffffff',
                        borderRadius,
                      }}
                    >
                      {itemHasImage ? (
                        itemBleedType === 'image_continuous' ? (
                          <img
                            src={art!.dataUrl}
                            alt=""
                            className="w-full h-full object-cover pointer-events-none"
                            style={{ transform: imageTransform }}
                          />
                        ) : itemBleedType === 'image_mirror' ? (
                          <>
                            <img
                              src={art!.dataUrl}
                              alt=""
                              className="absolute inset-0 w-full h-full object-cover filter scale-x-[-1.1] scale-y-[-1.1]"
                              style={{ transform: imageTransform }}
                            />
                            <div
                              className="relative overflow-hidden flex items-center justify-center"
                              style={{
                                width: `${itemInnerW}px`,
                                height: `${itemInnerH}px`,
                                borderRadius,
                              }}
                            >
                              <img
                                src={art!.dataUrl}
                                alt=""
                                className="w-full h-full object-cover"
                                style={{ transform: imageTransform }}
                              />
                            </div>
                          </>
                        ) : itemBleedType === 'image_blur' ? (
                          <>
                            <img
                              src={art!.dataUrl}
                              alt=""
                              className="absolute inset-0 w-full h-full object-cover filter blur-[4px] scale-110"
                              style={{ transform: imageTransform }}
                            />
                            <div
                              className="relative overflow-hidden flex items-center justify-center"
                              style={{
                                width: `${itemInnerW}px`,
                                height: `${itemInnerH}px`,
                                borderRadius,
                              }}
                            >
                              <img
                                src={art!.dataUrl}
                                alt=""
                                className="w-full h-full object-cover"
                                style={{ transform: imageTransform }}
                              />
                            </div>
                          </>
                        ) : (
                          <div
                            className="relative overflow-hidden flex items-center justify-center"
                            style={{
                              width: `${itemInnerW}px`,
                              height: `${itemInnerH}px`,
                              backgroundColor: itemFaceBg,
                              borderRadius,
                            }}
                          >
                            <img
                              src={art!.dataUrl}
                              alt=""
                              className="w-full h-full object-cover"
                              style={{ transform: imageTransform }}
                            />
                          </div>
                        )
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-[9px] font-mono text-slate-300">
                          #{pos.index + 1}
                        </div>
                      )}

                      {/* Cut line */}
                      {cutLineOptions.showCutLine && (
                        <div
                          className="absolute inset-0 pointer-events-none"
                          style={{
                            borderWidth: '1px',
                            borderStyle: cutLineOptions.cutLineStyle,
                            borderColor: cutLineOptions.cutLineColor,
                            opacity: cutLineOptions.cutLineOpacity,
                            borderRadius,
                          }}
                        />
                      )}

                      {/* Inner guide */}
                      {cutLineOptions.showInnerGuide && (
                        <div
                          className="absolute pointer-events-none border border-dashed border-indigo-400/50"
                          style={{
                            width: `${itemInnerW}px`,
                            height: `${itemInnerH}px`,
                            borderRadius,
                          }}
                        />
                      )}
                    </div>
                  );
                })}

                <div className="absolute bottom-2 left-3 right-3 flex justify-between text-[8px] text-slate-400 font-mono pointer-events-none">
                  <span>ZavaPrint • A4 ({layout.pageWidthMm}×{layout.pageHeightMm}mm) • {layout.totalPositions} bottons</span>
                  <span>{foilOptions.enabled ? 'MATRIZ FOIL' : 'IMPRESSÃO COLORIDA'}</span>
                </div>
              </div>
            ) : (
              /* 3D Simulation */
              <div className="flex flex-col items-center justify-center p-6 space-y-5 max-w-md text-center">
                <div className="relative">
                  <div className="w-64 h-64 rounded-full bg-gradient-to-tr from-slate-400 via-slate-200 to-white shadow-2xl p-1 relative flex items-center justify-center">
                    {/* The Crimped / Folded Bleed Rim */}
                    <div
                      className="w-60 h-60 rounded-full overflow-hidden relative shadow-inner flex items-center justify-center"
                      style={{
                        backgroundColor: hasImage
                          ? bleedType === 'solid_color'
                            ? bleedColor
                            : faceBgColor || '#ffffff'
                          : '#f1f5f9',
                      }}
                    >
                      {/* Background image in bleed if image_continuous / mirror / blur */}
                      {hasImage && bleedType !== 'solid_color' && (
                        <img
                          src={representativeArt!.dataUrl}
                          alt=""
                          className={`absolute inset-0 w-full h-full object-cover ${
                            bleedType === 'image_blur'
                              ? 'filter blur-[5px] scale-110'
                              : bleedType === 'image_mirror'
                              ? 'scale-x-[-1.1] scale-y-[-1.1]'
                              : ''
                          }`}
                          style={{
                            transform: `scale(${representativeArt?.scale || 1}) translate(${
                              ((representativeArt?.panX || 0) / preset.outerDiameterMm) * 100
                            }%, ${
                              ((representativeArt?.panY || 0) / preset.outerDiameterMm) * 100
                            }%) rotate(${representativeArt?.rotation || 0}deg)`,
                          }}
                        />
                      )}

                      {/* Front Visible Face */}
                      <div
                        className="rounded-full overflow-hidden relative shadow-md flex items-center justify-center"
                        style={{
                          width: `${(preset.innerDiameterMm / preset.outerDiameterMm) * 100}%`,
                          height: `${(preset.innerDiameterMm / preset.outerDiameterMm) * 100}%`,
                          backgroundColor: hasImage
                            ? bleedType === 'solid_color'
                              ? faceBgColor
                              : 'transparent'
                            : '#ffffff',
                        }}
                      >
                        {hasImage ? (
                          <img
                            src={representativeArt!.dataUrl}
                            alt="Face do botton"
                            className="w-full h-full object-cover"
                            style={{
                              transform: `scale(${representativeArt?.scale || 1}) translate(${
                                ((representativeArt?.panX || 0) / preset.outerDiameterMm) * 100
                              }%, ${
                                ((representativeArt?.panY || 0) / preset.outerDiameterMm) * 100
                              }%) rotate(${representativeArt?.rotation || 0}deg)`,
                            }}
                          />
                        ) : (
                          <div className="text-center p-4 text-xs text-slate-400">
                            Modelo vazio pronto para receber arte
                          </div>
                        )}
                      </div>

                      {/* Acrylic dome reflection */}
                      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-white/35 pointer-events-none rounded-full" />
                      <div className="absolute top-4 left-8 w-24 h-10 bg-white/25 rounded-full blur-xs -rotate-45 pointer-events-none" />
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <span className="text-sm font-bold text-slate-900 block">
                    Simulação Realista do Botton Prensado
                  </span>
                  <p className="text-xs text-slate-600">
                    {hasImage
                      ? 'Visualização realista da face frontal com a sangria dobrada na concha de metal.'
                      : 'Carregue uma imagem na tela principal para ver a simulação com sua arte aplicada.'}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Right Adjuster Controls Sidebar */}
          <div className="w-full md:w-80 bg-white border-t md:border-t-0 md:border-l border-slate-200 p-5 overflow-y-auto space-y-4 shrink-0">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Sliders className="w-4 h-4 text-indigo-600" />
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Ajuste Rápido de Margens
                </h3>
              </div>
              <p className="text-[11px] text-slate-500 mb-3">
                Ajuste os milímetros para alinhar perfeitamente com sua impressora.
              </p>

              <div className="space-y-2.5">
                <div>
                  <div className="flex justify-between text-xs text-slate-700 mb-0.5">
                    <span>Superior</span>
                    <span className="font-mono font-semibold">{margins.top} mm</span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="30"
                    value={margins.top}
                    onChange={(e) =>
                      onChangeMargins({ ...margins, top: Number(e.target.value) })
                    }
                    className="w-full accent-indigo-600"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-700 mb-0.5">
                    <span>Inferior</span>
                    <span className="font-mono font-semibold">{margins.bottom} mm</span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="30"
                    value={margins.bottom}
                    onChange={(e) =>
                      onChangeMargins({ ...margins, bottom: Number(e.target.value) })
                    }
                    className="w-full accent-indigo-600"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-700 mb-0.5">
                    <span>Esquerda</span>
                    <span className="font-mono font-semibold">{margins.left} mm</span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="30"
                    value={margins.left}
                    onChange={(e) =>
                      onChangeMargins({ ...margins, left: Number(e.target.value) })
                    }
                    className="w-full accent-indigo-600"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-slate-700 mb-0.5">
                    <span>Direita</span>
                    <span className="font-mono font-semibold">{margins.right} mm</span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="30"
                    value={margins.right}
                    onChange={(e) =>
                      onChangeMargins({ ...margins, right: Number(e.target.value) })
                    }
                    className="w-full accent-indigo-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-1.5 mt-2.5 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => onChangeMargins({ top: 5, bottom: 5, left: 5, right: 5 })}
                  className="py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-center cursor-pointer"
                >
                  5 mm
                </button>
                <button
                  type="button"
                  onClick={() => onChangeMargins({ top: 8, bottom: 8, left: 8, right: 8 })}
                  className="py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-center cursor-pointer"
                >
                  8 mm
                </button>
                <button
                  type="button"
                  onClick={() => onChangeMargins({ top: 12, bottom: 12, left: 12, right: 12 })}
                  className="py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-center cursor-pointer"
                >
                  12 mm
                </button>
              </div>
            </div>

            {/* Production Specs */}
            <div className="pt-2 border-t border-slate-200 space-y-1.5 text-xs text-slate-600 font-mono">
              <span className="text-xs font-bold text-slate-900 block font-sans">
                Ficha Técnica ZavaPrint
              </span>
              <div className="flex justify-between py-0.5 border-b border-slate-100">
                <span className="text-slate-500">Modelo:</span>
                <span className="font-bold text-slate-800">{preset.name}</span>
              </div>
              <div className="flex justify-between py-0.5 border-b border-slate-100">
                <span className="text-slate-500">Qtd por Folha:</span>
                <span className="font-bold text-indigo-700">{layout.totalPositions} bottons</span>
              </div>
              <div className="flex justify-between py-0.5 border-b border-slate-100">
                <span className="text-slate-500">Aproveitamento:</span>
                <span className="font-bold text-slate-800">{layout.efficiencyPercent}%</span>
              </div>
            </div>

            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-950 space-y-1">
              <span className="font-bold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
                Dica ZavaPrint:
              </span>
              <p>Na impressora, marque sempre <strong>Escala: 100%</strong> (tamanho real) para manter as medidas exatas de corte e prensagem.</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-2.5 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="text-xs text-slate-500">
            Total de <strong>{layout.totalPositions} bottons</strong> configurados na folha A4
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onExportPng}
              type="button"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl cursor-pointer"
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Baixar PNG</span>
            </button>

            <button
              onClick={onExportPdf}
              type="button"
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs cursor-pointer"
            >
              <FileDown className="w-3.5 h-3.5 text-amber-400" />
              <span>Baixar PDF para Impressão</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
