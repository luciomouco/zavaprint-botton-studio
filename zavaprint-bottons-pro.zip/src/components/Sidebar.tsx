import React, { useRef, useState } from 'react';
import {
  Sliders,
  Scissors,
  Sparkles,
  Upload,
  Settings2,
  Check,
  Trash2,
  Copy,
  Palette,
  Type,
  Disc,
  Square,
  RectangleHorizontal,
  Heart,
  ImageIcon,
  Sparkle,
  RotateCcw,
  Layers,
  ChevronRight
} from 'lucide-react';
import {
  ALL_BUTTON_PRESETS,
  BleedType,
  ButtonPreset,
  ButtonShape,
  CutLineOptions,
  FoilMatrixOptions,
  LayoutArrangement,
  LayoutCalculation,
  PageMarginsMm,
  PageOrientation,
  BottonArtwork,
} from '../types/button';
import { SampleBadge } from '../utils/sampleDesigns';

interface SidebarProps {
  currentPreset: ButtonPreset;
  onSelectPreset: (preset: ButtonPreset) => void;
  orientation: PageOrientation;
  onChangeOrientation: (orientation: PageOrientation) => void;
  arrangement: LayoutArrangement;
  onChangeArrangement: (arrangement: LayoutArrangement) => void;
  margins: PageMarginsMm;
  onChangeMargins: (margins: PageMarginsMm) => void;
  gapMm: number;
  onChangeGapMm: (gap: number) => void;
  offsetX: number;
  offsetY: number;
  onChangeOffsets: (x: number, y: number) => void;
  cutLineOptions: CutLineOptions;
  onChangeCutLineOptions: (options: CutLineOptions) => void;
  foilOptions: FoilMatrixOptions;
  onChangeFoilOptions: (options: FoilMatrixOptions) => void;
  layout: LayoutCalculation;
  defaultArt: BottonArtwork | null;
  onUpdateDefaultArt: (updated: Partial<BottonArtwork>) => void;
  onUploadImage: (file: File, applyToAll: boolean) => void;
  sampleBadges: SampleBadge[];
  onSelectSample: (badge: SampleBadge, applyToAll: boolean) => void;
  onClearArtworks: () => void;
  onApplyDefaultToAll: () => void;
  onResetProject: () => void;
  customInnerMm: number;
  customOuterMm: number;
  onChangeCustomDimensions: (inner: number, outer: number) => void;
  isOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPreset,
  onSelectPreset,
  orientation,
  onChangeOrientation,
  arrangement,
  onChangeArrangement,
  margins,
  onChangeMargins,
  gapMm,
  onChangeGapMm,
  offsetX,
  offsetY,
  onChangeOffsets,
  cutLineOptions,
  onChangeCutLineOptions,
  foilOptions,
  onChangeFoilOptions,
  layout,
  defaultArt,
  onUpdateDefaultArt,
  onUploadImage,
  sampleBadges,
  onSelectSample,
  onClearArtworks,
  onApplyDefaultToAll,
  onResetProject,
  customInnerMm,
  customOuterMm,
  onChangeCustomDimensions,
  isOpen,
  onCloseMobile,
}) => {
  const [activeTab, setActiveTab] = useState<
    'sangria' | 'formatos' | 'artes' | 'margens' | 'corte' | 'foil'
  >('sangria');

  const [shapeFilter, setShapeFilter] = useState<'all' | ButtonShape>('all');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredPresets = ALL_BUTTON_PRESETS.filter((p) =>
    shapeFilter === 'all' ? true : p.shape === shapeFilter
  );

  const QUICK_PALETTE = [
    '#ef4444', // Vermelho (como no print da Bulma)
    '#0f172a', // Preto ônix Zava
    '#ffffff', // Branco
    '#1e293b', // Grafite
    '#2563eb', // Azul royal
    '#16a34a', // Verde
    '#f59e0b', // Dourado âmbar Zava
    '#ec4899', // Rosa
    '#78350f', // Marrom
    '#06b6d4', // Ciano
  ];

  const currentBleedType: BleedType = defaultArt?.bleedType || 'image_continuous';

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-slate-900/30 backdrop-blur-xs z-20 lg:hidden"
        />
      )}

      <aside
        className={`no-print fixed lg:static top-0 bottom-0 left-0 w-80 lg:w-96 bg-white border-r border-slate-200/90 flex flex-col shrink-0 h-full overflow-hidden select-none z-30 transition-transform duration-200 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Soft Sub-header / Tabs Bar */}
        <div className="flex items-center border-b border-slate-200/80 px-2 py-2 gap-1 bg-slate-50/60 overflow-x-auto shrink-0">
          <button
            onClick={() => setActiveTab('sangria')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'sangria'
                ? 'bg-white text-indigo-600 shadow-2xs border border-slate-200/90'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
            title="Escolha a sangria com a própria imagem ou cor"
          >
            <Palette className="w-3.5 h-3.5 text-indigo-600" />
            <span>Sangria</span>
          </button>

          <button
            onClick={() => setActiveTab('formatos')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'formatos'
                ? 'bg-white text-indigo-600 shadow-2xs border border-slate-200/90'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
          >
            <Sliders className="w-3.5 h-3.5 text-slate-500" />
            <span>Tamanhos</span>
          </button>

          <button
            onClick={() => setActiveTab('artes')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'artes'
                ? 'bg-white text-indigo-600 shadow-2xs border border-slate-200/90'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
          >
            <Upload className="w-3.5 h-3.5 text-slate-500" />
            <span>Artes</span>
          </button>

          <button
            onClick={() => setActiveTab('margens')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'margens'
                ? 'bg-white text-indigo-600 shadow-2xs border border-slate-200/90'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
          >
            <Settings2 className="w-3.5 h-3.5 text-slate-500" />
            <span>Margens</span>
          </button>

          <button
            onClick={() => setActiveTab('corte')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'corte'
                ? 'bg-white text-indigo-600 shadow-2xs border border-slate-200/90'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
          >
            <Scissors className="w-3.5 h-3.5 text-slate-500" />
            <span>Corte</span>
          </button>

          <button
            onClick={() => setActiveTab('foil')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
              activeTab === 'foil'
                ? 'bg-white text-amber-700 shadow-2xs border border-slate-200/90'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/70'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Foil</span>
          </button>
        </div>

        {/* Tab Contents Scrollable */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* TAB: SANGRIA & FUNDO */}
          {activeTab === 'sangria' && (
            <div className="space-y-4">
              <div className="p-3 bg-indigo-50/60 rounded-xl border border-indigo-100/80">
                <span className="text-xs font-bold text-indigo-950 block">
                  Sangria Personalizada
                </span>
                <p className="text-[11px] text-indigo-800/90 mt-1 leading-normal">
                  Escolha se a sangria deve continuar com a <strong>própria imagem</strong> (sem cortes) ou receber uma <strong>cor sólida</strong>.
                </p>
              </div>

              {/* Sangria Options */}
              <div className="space-y-2">
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                  Opções de Sangria
                </label>

                {/* Option 1: Própria Imagem Contínua */}
                <button
                  type="button"
                  onClick={() => onUpdateDefaultArt({ bleedType: 'image_continuous' })}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer ${
                    currentBleedType === 'image_continuous'
                      ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-600 shadow-2xs'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                      <ImageIcon className="w-3.5 h-3.5 text-indigo-600" />
                      Própria Imagem Contínua (Recomendado)
                    </span>
                    {currentBleedType === 'image_continuous' && (
                      <Check className="w-4 h-4 text-indigo-600 stroke-[3]" />
                    )}
                  </div>
                  <p className="mt-1 text-[11px] text-slate-500 leading-tight pl-5">
                    A imagem cobre a face frontal ({currentPreset.innerDiameterMm} mm) e continua naturalmente até a linha de corte ({currentPreset.outerDiameterMm} mm).
                  </p>
                </button>

                {/* Option 2: Própria Imagem Espelhada */}
                <button
                  type="button"
                  onClick={() => onUpdateDefaultArt({ bleedType: 'image_mirror' })}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer ${
                    currentBleedType === 'image_mirror'
                      ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-600 shadow-2xs'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                      <Sparkle className="w-3.5 h-3.5 text-indigo-600" />
                      Própria Imagem Espelhada (Borda Espelho)
                    </span>
                    {currentBleedType === 'image_mirror' && (
                      <Check className="w-4 h-4 text-indigo-600 stroke-[3]" />
                    )}
                  </div>
                  <p className="mt-1 text-[11px] text-slate-500 leading-tight pl-5">
                    As bordas da imagem são refletidas para a sangria (o mesmo efeito dos quadros canvas da ZavaPrint).
                  </p>
                </button>

                {/* Option 3: Própria Imagem Desfocada */}
                <button
                  type="button"
                  onClick={() => onUpdateDefaultArt({ bleedType: 'image_blur' })}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer ${
                    currentBleedType === 'image_blur'
                      ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-600 shadow-2xs'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                      Própria Imagem Desfocada (Ambient Blur)
                    </span>
                    {currentBleedType === 'image_blur' && (
                      <Check className="w-4 h-4 text-indigo-600 stroke-[3]" />
                    )}
                  </div>
                  <p className="mt-1 text-[11px] text-slate-500 leading-tight pl-5">
                    Fundo suave com desfoque artístico das mesmas cores da imagem.
                  </p>
                </button>

                {/* Option 4: Cor Sólida */}
                <button
                  type="button"
                  onClick={() => onUpdateDefaultArt({ bleedType: 'solid_color' })}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer ${
                    currentBleedType === 'solid_color'
                      ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-600 shadow-2xs'
                      : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                      <Palette className="w-3.5 h-3.5 text-indigo-600" />
                      Cor Sólida na Sangria (Anel Colorido)
                    </span>
                    {currentBleedType === 'solid_color' && (
                      <Check className="w-4 h-4 text-indigo-600 stroke-[3]" />
                    )}
                  </div>
                  <p className="mt-1 text-[11px] text-slate-500 leading-tight pl-5">
                    A imagem fica na face e a sangria ganha uma cor fixa personalizada.
                  </p>
                </button>
              </div>

              {/* Color Picker when solid_color is selected */}
              {currentBleedType === 'solid_color' && (
                <div className="p-3 bg-slate-50/70 rounded-xl border border-slate-200 space-y-2.5 animate-in fade-in duration-150">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">
                      Cor da Sangria
                    </span>
                    <span className="text-xs font-mono font-semibold text-slate-700">
                      {defaultArt?.bleedColor || '#ef4444'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={defaultArt?.bleedColor || '#ef4444'}
                      onChange={(e) => onUpdateDefaultArt({ bleedColor: e.target.value })}
                      className="w-10 h-10 rounded-lg border border-slate-300 p-0.5 cursor-pointer shrink-0"
                    />
                    <div className="grid grid-cols-5 gap-1.5 flex-1">
                      {QUICK_PALETTE.map((c) => (
                        <button
                          key={c}
                          type="button"
                          onClick={() => onUpdateDefaultArt({ bleedColor: c })}
                          style={{ backgroundColor: c }}
                          className={`h-7 rounded-md border transition-transform cursor-pointer hover:scale-105 ${
                            (defaultArt?.bleedColor || '#ef4444').toLowerCase() === c.toLowerCase()
                              ? 'border-indigo-600 ring-2 ring-indigo-400'
                              : 'border-slate-300/80'
                          }`}
                          title={c}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Optional Rim Text */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <div className="flex items-center gap-1.5">
                  <Type className="w-3.5 h-3.5 text-indigo-600" />
                  <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                    Texto na Borda de Sangria (Lateral)
                  </label>
                </div>
                <input
                  type="text"
                  placeholder="Ex: ZavaPrint • www.zavaprint.com.br"
                  value={defaultArt?.rimText || ''}
                  onChange={(e) => onUpdateDefaultArt({ rimText: e.target.value })}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium focus:bg-white focus:ring-2 focus:ring-indigo-500 transition-colors"
                />
              </div>
            </div>
          )}

          {/* TAB: FORMATOS */}
          {activeTab === 'formatos' && (
            <div className="space-y-4">
              {/* Shape filter */}
              <div className="flex items-center gap-1 p-1 bg-slate-100/80 rounded-lg">
                <button
                  type="button"
                  onClick={() => setShapeFilter('all')}
                  className={`flex-1 py-1 text-xs font-medium rounded-md transition-all ${
                    shapeFilter === 'all'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Todos
                </button>
                <button
                  type="button"
                  onClick={() => setShapeFilter('round')}
                  className={`flex-1 py-1 text-xs font-medium rounded-md transition-all flex items-center justify-center gap-1 ${
                    shapeFilter === 'round'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Disc className="w-3 h-3" />
                  <span>Redondo</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShapeFilter('square')}
                  className={`flex-1 py-1 text-xs font-medium rounded-md transition-all flex items-center justify-center gap-1 ${
                    shapeFilter === 'square'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Square className="w-3 h-3" />
                  <span>Quadrado</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShapeFilter('rectangle')}
                  className={`flex-1 py-1 text-xs font-medium rounded-md transition-all flex items-center justify-center gap-1 ${
                    shapeFilter === 'rectangle'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <RectangleHorizontal className="w-3 h-3" />
                  <span>Retângulo</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShapeFilter('heart')}
                  className={`flex-1 py-1 text-xs font-medium rounded-md transition-all flex items-center justify-center gap-1 ${
                    shapeFilter === 'heart'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Heart className="w-3 h-3 text-red-500" />
                  <span>Coração</span>
                </button>
              </div>

              <div className="space-y-1.5 max-h-[380px] overflow-y-auto pr-1">
                {filteredPresets.map((p) => {
                  const isSelected = currentPreset.id === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => onSelectPreset(p)}
                      className={`w-full text-left p-2.5 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-600 shadow-2xs'
                          : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs">{p.name}</span>
                        {isSelected && (
                          <span className="w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                            <Check className="w-2.5 h-2.5 stroke-[3]" />
                          </span>
                        )}
                      </div>
                      <div className="mt-0.5 flex items-center gap-2 text-[11px] text-slate-500 font-mono">
                        <span>Face: {p.innerDiameterMm} mm</span>
                        <span aria-hidden="true">·</span>
                        <span>Corte: {p.outerDiameterMm} mm</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Custom Dimensions */}
              {currentPreset.id === 'custom' && (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <span className="text-xs font-semibold text-slate-700 block">
                    Medidas Personalizadas (mm)
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[10px] text-slate-600 block mb-0.5">Face (mm)</label>
                      <input
                        type="number"
                        min={10}
                        max={150}
                        value={customInnerMm}
                        onChange={(e) =>
                          onChangeCustomDimensions(Number(e.target.value), customOuterMm)
                        }
                        className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-600 block mb-0.5">Corte + Sangria (mm)</label>
                      <input
                        type="number"
                        min={15}
                        max={200}
                        value={customOuterMm}
                        onChange={(e) =>
                          onChangeCustomDimensions(customInnerMm, Number(e.target.value))
                        }
                        className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-mono"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Orientation & Spacing */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                  Orientação da Folha A4
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => onChangeOrientation('portrait')}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg border text-center transition-all cursor-pointer ${
                      orientation === 'portrait'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                        : 'border-slate-200 bg-white text-slate-700'
                    }`}
                  >
                    Retrato (Vertical)
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeOrientation('landscape')}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg border text-center transition-all cursor-pointer ${
                      orientation === 'landscape'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                        : 'border-slate-200 bg-white text-slate-700'
                    }`}
                  >
                    Paisagem (Horizontal)
                  </button>
                </div>

                <div className="space-y-1 pt-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-700">Espaçamento entre cortes:</span>
                    <span className="font-mono font-semibold text-slate-900">{gapMm} mm</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="6"
                    step="0.5"
                    value={gapMm}
                    onChange={(e) => onChangeGapMm(Number(e.target.value))}
                    className="w-full accent-indigo-600"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB: ARTES & FOTOS */}
          {activeTab === 'artes' && (
            <div className="space-y-4">
              <input
                type="file"
                ref={fileInputRef}
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    onUploadImage(e.target.files[0], true);
                    e.target.value = '';
                  }
                }}
                accept="image/*"
                className="hidden"
              />

              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-300 hover:border-indigo-500 hover:bg-indigo-50/20 rounded-xl p-5 text-center cursor-pointer transition-colors"
              >
                <Upload className="w-7 h-7 text-indigo-600 mx-auto mb-2" />
                <span className="text-xs font-bold text-slate-800 block">
                  Clique para Escolher Sua Imagem
                </span>
                <span className="text-[11px] text-slate-500 mt-1 block">
                  PNG, JPG ou WEBP de alta resolução
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onApplyDefaultToAll}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                  <span>Replicar a Todos</span>
                </button>
                <button
                  type="button"
                  onClick={onClearArtworks}
                  className="inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Limpar</span>
                </button>
              </div>

              {/* Sample badges */}
              <div className="pt-2 border-t border-slate-100">
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block mb-2">
                  Imagens Rápidas
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {sampleBadges.map((badge) => (
                    <button
                      key={badge.id}
                      type="button"
                      onClick={() => onSelectSample(badge, true)}
                      className="p-2 border border-slate-200 hover:border-indigo-500 hover:shadow-xs rounded-xl text-left transition-all bg-white group cursor-pointer"
                    >
                      <div className="aspect-square w-full rounded-lg overflow-hidden bg-slate-100 relative mb-1.5">
                        <img
                          src={badge.dataUrl}
                          alt={badge.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                      </div>
                      <span className="text-xs font-semibold text-slate-800 block truncate">
                        {badge.name}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {badge.category}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB: MARGENS */}
          {activeTab === 'margens' && (
            <div className="space-y-4">
              <div>
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block mb-1">
                  Margens da Folha A4 (mm)
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[11px] text-slate-600 block mb-0.5">Topo</label>
                    <input
                      type="number"
                      min={0}
                      max={40}
                      value={margins.top}
                      onChange={(e) =>
                        onChangeMargins({ ...margins, top: Math.max(0, Number(e.target.value)) })
                      }
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-600 block mb-0.5">Base</label>
                    <input
                      type="number"
                      min={0}
                      max={40}
                      value={margins.bottom}
                      onChange={(e) =>
                        onChangeMargins({ ...margins, bottom: Math.max(0, Number(e.target.value)) })
                      }
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-600 block mb-0.5">Esquerda</label>
                    <input
                      type="number"
                      min={0}
                      max={40}
                      value={margins.left}
                      onChange={(e) =>
                        onChangeMargins({ ...margins, left: Math.max(0, Number(e.target.value)) })
                      }
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-600 block mb-0.5">Direita</label>
                    <input
                      type="number"
                      min={0}
                      max={40}
                      value={margins.right}
                      onChange={(e) =>
                        onChangeMargins({ ...margins, right: Math.max(0, Number(e.target.value)) })
                      }
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 space-y-2">
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                  Calibração da Impressora (Offset)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="flex justify-between text-[11px] text-slate-600 mb-0.5">
                      <span>Eixo X</span>
                      <span className="font-mono">{offsetX} mm</span>
                    </div>
                    <input
                      type="range"
                      min="-10"
                      max="10"
                      step="0.5"
                      value={offsetX}
                      onChange={(e) => onChangeOffsets(Number(e.target.value), offsetY)}
                      className="w-full accent-indigo-600"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-[11px] text-slate-600 mb-0.5">
                      <span>Eixo Y</span>
                      <span className="font-mono">{offsetY} mm</span>
                    </div>
                    <input
                      type="range"
                      min="-10"
                      max="10"
                      step="0.5"
                      value={offsetY}
                      onChange={(e) => onChangeOffsets(offsetX, Number(e.target.value))}
                      className="w-full accent-indigo-600"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: CORTE */}
          {activeTab === 'corte' && (
            <div className="space-y-4">
              <div>
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block mb-1">
                  Linha de Corte Circular
                </label>
                <div className="space-y-1 mb-3">
                  <div className="flex justify-between text-xs">
                    <span className="font-medium text-slate-700">Opacidade:</span>
                    <span className="font-mono font-semibold">
                      {Math.round(cutLineOptions.cutLineOpacity * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="1.0"
                    step="0.05"
                    value={cutLineOptions.cutLineOpacity}
                    onChange={(e) =>
                      onChangeCutLineOptions({
                        ...cutLineOptions,
                        cutLineOpacity: Number(e.target.value),
                      })
                    }
                    className="w-full accent-indigo-600"
                  />
                </div>

                <div className="space-y-1.5 mb-3">
                  <label className="text-xs font-medium text-slate-700 block">
                    Estilo do Traço
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['solid', 'dashed', 'dotted'] as const).map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() =>
                          onChangeCutLineOptions({ ...cutLineOptions, cutLineStyle: s })
                        }
                        className={`py-1 text-xs font-medium rounded-lg border text-center transition-all ${
                          cutLineOptions.cutLineStyle === s
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-bold'
                            : 'border-slate-200 bg-white text-slate-600'
                        }`}
                      >
                        {s === 'solid' ? 'Contínuo' : s === 'dashed' ? 'Tracejado' : 'Pontilhado'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100">
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={cutLineOptions.showInnerGuide}
                      onChange={(e) =>
                        onChangeCutLineOptions({
                          ...cutLineOptions,
                          showInnerGuide: e.target.checked,
                        })
                      }
                      className="w-4 h-4 accent-indigo-600 rounded"
                    />
                    <span>Mostrar linha guia da face frontal na tela</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* TAB: FOIL LASER */}
          {activeTab === 'foil' && (
            <div className="space-y-4">
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
                <span className="text-xs font-bold text-amber-900 block">
                  Matriz Foil Laser (Hot Stamping)
                </span>
                <p className="mt-1 text-[11px] text-amber-800">
                  Converte artes para preto sólido K:100% para toner laser fixar foil térmico.
                </p>
              </div>

              <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200">
                <span className="text-xs font-bold text-slate-900">
                  Ativar Matriz Foil Laser
                </span>
                <input
                  type="checkbox"
                  checked={foilOptions.enabled}
                  onChange={(e) =>
                    onChangeFoilOptions({ ...foilOptions, enabled: e.target.checked })
                  }
                  className="w-5 h-5 accent-amber-600 rounded cursor-pointer"
                />
              </div>
            </div>
          )}
        </div>

        {/* Bottom Sidebar Action: Zerar / Novo Projeto */}
        <div className="border-t border-slate-200/80 p-3 bg-slate-50/70 shrink-0 space-y-2">
          <button
            type="button"
            onClick={onResetProject}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-indigo-700 bg-white hover:bg-indigo-50/70 border border-slate-200/90 rounded-xl transition-all cursor-pointer shadow-2xs"
            title="Voltar todas as configurações para o padrão e iniciar um novo projeto"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
            <span>Zerar Configurações (Novo Projeto)</span>
          </button>

          <div className="flex items-center justify-between text-[11px] text-slate-500 px-1 font-medium">
            <span>{currentPreset.name}</span>
            <span className="font-mono text-indigo-700 font-semibold">
              {layout.totalPositions} bottons / A4
            </span>
          </div>
        </div>
      </aside>
    </>
  );
};
