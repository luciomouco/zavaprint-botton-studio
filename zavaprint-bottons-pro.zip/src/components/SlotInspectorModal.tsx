import React, { useRef } from 'react';
import {
  X,
  ZoomIn,
  Move,
  RotateCw,
  Copy,
  Upload,
  RotateCcw,
  Palette,
  Type,
  ImageIcon,
  Sparkle,
  Sparkles
} from 'lucide-react';
import { BleedType, BottonArtwork, ButtonPreset } from '../types/button';

interface SlotInspectorModalProps {
  slotIndex: number;
  artwork: BottonArtwork | undefined;
  defaultArt: BottonArtwork | null;
  preset: ButtonPreset;
  onClose: () => void;
  onUpdateArtwork: (index: number, updated: Partial<BottonArtwork>) => void;
  onApplyToAll: (index: number) => void;
  onUploadSpecificImage: (index: number, file: File) => void;
}

export const SlotInspectorModal: React.FC<SlotInspectorModalProps> = ({
  slotIndex,
  artwork,
  defaultArt,
  preset,
  onClose,
  onUpdateArtwork,
  onApplyToAll,
  onUploadSpecificImage,
}) => {
  const current = artwork || defaultArt;
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scale = current?.scale || 1.0;
  const panX = current?.panX || 0;
  const panY = current?.panY || 0;
  const rotation = current?.rotation || 0;
  const bleedColor = current?.bleedColor || '#ef4444';
  const faceBgColor = current?.faceBgColor || '#ffffff';
  const bleedType: BleedType = current?.bleedType || 'image_continuous';
  const rimText = current?.rimText || '';

  const QUICK_COLORS = [
    '#ef4444',
    '#0f172a',
    '#ffffff',
    '#1e293b',
    '#dc2626',
    '#2563eb',
    '#16a34a',
    '#f59e0b',
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onUploadSpecificImage(slotIndex, e.target.files[0]);
    }
  };

  const borderRadius =
    preset.shape === 'round' ? '9999px' : preset.shape === 'heart' ? '0' : '8px';

  const imageTransform = `scale(${scale}) translate(${
    (panX / preset.outerDiameterMm) * 100
  }%, ${(panY / preset.outerDiameterMm) * 100}%) rotate(${rotation}deg)`;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-150">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-5 py-3 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Personalizar Botton #{slotIndex + 1}
            </h3>
            <p className="text-xs text-slate-500 font-mono">
              {preset.name} • Face: {preset.innerDiameterMm} mm • Corte: {preset.outerDiameterMm} mm
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Visual Preview */}
          <div className="flex flex-col items-center justify-center">
            <div
              className="w-56 h-56 relative flex items-center justify-center border-2 border-slate-300 shadow-md overflow-hidden"
              style={{
                backgroundColor: bleedType === 'solid_color' ? bleedColor : (faceBgColor || '#ffffff'),
                borderRadius,
              }}
            >
              {bleedType === 'image_continuous' ? (
                /* Continuous image */
                current?.dataUrl && (
                  <img
                    src={current.dataUrl}
                    alt="Prévia"
                    className="w-full h-full object-cover select-none pointer-events-none"
                    style={{ transform: imageTransform }}
                  />
                )
              ) : bleedType === 'image_mirror' ? (
                /* Mirrored background + face */
                <>
                  {current?.dataUrl && (
                    <img
                      src={current.dataUrl}
                      alt=""
                      className="absolute inset-0 w-full h-full object-cover filter brightness-95 scale-x-[-1.1] scale-y-[-1.1]"
                      style={{ transform: imageTransform }}
                    />
                  )}
                  <div
                    className="relative overflow-hidden flex items-center justify-center shadow-xs"
                    style={{
                      width: `${(preset.innerDiameterMm / preset.outerDiameterMm) * 100}%`,
                      height: `${(preset.innerDiameterMm / preset.outerDiameterMm) * 100}%`,
                      borderRadius,
                    }}
                  >
                    {current?.dataUrl && (
                      <img
                        src={current.dataUrl}
                        alt=""
                        className="w-full h-full object-cover"
                        style={{ transform: imageTransform }}
                      />
                    )}
                  </div>
                </>
              ) : bleedType === 'image_blur' ? (
                /* Blurred background + face */
                <>
                  {current?.dataUrl && (
                    <img
                      src={current.dataUrl}
                      alt=""
                      className="absolute inset-0 w-full h-full object-cover filter blur-[6px] scale-110 opacity-80"
                      style={{ transform: imageTransform }}
                    />
                  )}
                  <div
                    className="relative overflow-hidden flex items-center justify-center shadow-xs"
                    style={{
                      width: `${(preset.innerDiameterMm / preset.outerDiameterMm) * 100}%`,
                      height: `${(preset.innerDiameterMm / preset.outerDiameterMm) * 100}%`,
                      borderRadius,
                    }}
                  >
                    {current?.dataUrl && (
                      <img
                        src={current.dataUrl}
                        alt=""
                        className="w-full h-full object-cover"
                        style={{ transform: imageTransform }}
                      />
                    )}
                  </div>
                </>
              ) : (
                /* Solid color in bleed */
                <div
                  className="relative overflow-hidden flex items-center justify-center"
                  style={{
                    width: `${(preset.innerDiameterMm / preset.outerDiameterMm) * 100}%`,
                    height: `${(preset.innerDiameterMm / preset.outerDiameterMm) * 100}%`,
                    backgroundColor: faceBgColor,
                    borderRadius,
                  }}
                >
                  {current?.dataUrl ? (
                    <img
                      src={current.dataUrl}
                      alt="Prévia"
                      className="w-full h-full object-cover select-none pointer-events-none"
                      style={{ transform: imageTransform }}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xs text-slate-400">
                      Sem imagem
                    </div>
                  )}
                </div>
              )}

              {/* Inner Face Boundary Guide */}
              <div
                className="absolute inset-0 m-auto pointer-events-none border-2 border-dashed border-indigo-500/80"
                style={{
                  width: `${(preset.innerDiameterMm / preset.outerDiameterMm) * 100}%`,
                  height: `${(preset.innerDiameterMm / preset.outerDiameterMm) * 100}%`,
                  borderRadius,
                }}
              />
            </div>

            <div className="mt-2 text-center text-xs text-slate-500">
              <span className="font-semibold text-indigo-700">Linha tracejada:</span> Limite da face frontal ({preset.innerDiameterMm} mm).
              <br />
              <span className="font-semibold text-slate-700">Área externa:</span> Sangria ({preset.outerDiameterMm} mm) que vira para a concha de metal.
            </div>
          </div>

          {/* Bleed Mode Selection */}
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
            <span className="text-xs font-bold text-slate-800 block">
              Tipo de Sangria Deste Botton
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => onUpdateArtwork(slotIndex, { bleedType: 'image_continuous' })}
                className={`p-2 text-xs font-semibold rounded-md border text-center transition-colors cursor-pointer ${
                  bleedType === 'image_continuous'
                    ? 'border-indigo-600 bg-white text-indigo-700 shadow-xs ring-1 ring-indigo-500'
                    : 'border-slate-200 bg-slate-100 text-slate-600'
                }`}
              >
                Própria Imagem Contínua
              </button>
              <button
                type="button"
                onClick={() => onUpdateArtwork(slotIndex, { bleedType: 'image_mirror' })}
                className={`p-2 text-xs font-semibold rounded-md border text-center transition-colors cursor-pointer ${
                  bleedType === 'image_mirror'
                    ? 'border-indigo-600 bg-white text-indigo-700 shadow-xs ring-1 ring-indigo-500'
                    : 'border-slate-200 bg-slate-100 text-slate-600'
                }`}
              >
                Própria Imagem Espelhada
              </button>
              <button
                type="button"
                onClick={() => onUpdateArtwork(slotIndex, { bleedType: 'image_blur' })}
                className={`p-2 text-xs font-semibold rounded-md border text-center transition-colors cursor-pointer ${
                  bleedType === 'image_blur'
                    ? 'border-indigo-600 bg-white text-indigo-700 shadow-xs ring-1 ring-indigo-500'
                    : 'border-slate-200 bg-slate-100 text-slate-600'
                }`}
              >
                Própria Imagem Desfocada
              </button>
              <button
                type="button"
                onClick={() => onUpdateArtwork(slotIndex, { bleedType: 'solid_color' })}
                className={`p-2 text-xs font-semibold rounded-md border text-center transition-colors cursor-pointer ${
                  bleedType === 'solid_color'
                    ? 'border-indigo-600 bg-white text-indigo-700 shadow-xs ring-1 ring-indigo-500'
                    : 'border-slate-200 bg-slate-100 text-slate-600'
                }`}
              >
                Cor Sólida na Sangria
              </button>
            </div>
          </div>

          {/* Color pickers if solid color is active */}
          {bleedType === 'solid_color' && (
            <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
              <label className="text-xs font-bold text-slate-700 block flex items-center gap-1">
                <Palette className="w-3.5 h-3.5 text-slate-500" />
                Cor da Sangria: {bleedColor}
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={bleedColor}
                  onChange={(e) => onUpdateArtwork(slotIndex, { bleedColor: e.target.value })}
                  className="w-8 h-8 rounded border border-slate-300 p-0.5 cursor-pointer shrink-0"
                />
                <div className="flex gap-1 flex-wrap">
                  {QUICK_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => onUpdateArtwork(slotIndex, { bleedColor: c })}
                      style={{ backgroundColor: c }}
                      className="w-5 h-5 rounded border border-slate-300"
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Zoom & Pan Sliders */}
          <div className="space-y-3 pt-2 border-t border-slate-200">
            <div className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                  <ZoomIn className="w-3.5 h-3.5 text-slate-500" />
                  Zoom da Imagem
                </span>
                <span className="font-mono font-semibold text-indigo-700">
                  {Math.round(scale * 100)}%
                </span>
              </div>
              <input
                type="range"
                min="0.4"
                max="2.5"
                step="0.05"
                value={scale}
                onChange={(e) => onUpdateArtwork(slotIndex, { scale: Number(e.target.value) })}
                className="w-full accent-indigo-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="flex justify-between text-xs text-slate-600 mb-1">
                  <span>Posição X</span>
                  <span className="font-mono">{panX} mm</span>
                </div>
                <input
                  type="range"
                  min="-20"
                  max="20"
                  step="0.5"
                  value={panX}
                  onChange={(e) => onUpdateArtwork(slotIndex, { panX: Number(e.target.value) })}
                  className="w-full accent-indigo-600"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-600 mb-1">
                  <span>Posição Y</span>
                  <span className="font-mono">{panY} mm</span>
                </div>
                <input
                  type="range"
                  min="-20"
                  max="20"
                  step="0.5"
                  value={panY}
                  onChange={(e) => onUpdateArtwork(slotIndex, { panY: Number(e.target.value) })}
                  className="w-full accent-indigo-600"
                />
              </div>
            </div>

            {/* Rotation */}
            <div className="flex items-center justify-between pt-1">
              <span className="text-xs font-semibold text-slate-700 flex items-center gap-1">
                <RotateCw className="w-3.5 h-3.5 text-slate-500" />
                Rotação
              </span>
              <div className="flex gap-1">
                {[0, 90, 180, 270].map((deg) => (
                  <button
                    key={deg}
                    type="button"
                    onClick={() => onUpdateArtwork(slotIndex, { rotation: deg })}
                    className={`px-2 py-0.5 text-xs font-mono rounded border ${
                      rotation === deg
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-bold'
                        : 'border-slate-200 bg-white text-slate-600'
                    }`}
                  >
                    {deg}°
                  </button>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2 border-t border-slate-200 flex gap-2">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Trocar Imagem Deste Botton</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  onUpdateArtwork(slotIndex, {
                    scale: 1.0,
                    panX: 0,
                    panY: 0,
                    rotation: 0,
                  })
                }
                className="px-2.5 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                title="Resetar escala e posição"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            type="button"
            onClick={() => onApplyToAll(slotIndex)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Aplicar Este Padrão a Toda a Folha</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            Concluir
          </button>
        </div>
      </div>
    </div>
  );
};
