import React, { useState, useRef, useEffect } from 'react';
import {
  ZoomIn,
  ZoomOut,
  Edit2,
  Copy,
  Trash2,
  RotateCw,
  Plus,
  UploadCloud
} from 'lucide-react';
import {
  BleedType,
  BottonArtwork,
  CutLineOptions,
  FoilMatrixOptions,
  LayoutCalculation,
} from '../types/button';

interface A4WorkspaceProps {
  layout: LayoutCalculation;
  artworks: Record<number, BottonArtwork>;
  defaultArt: BottonArtwork | null;
  cutLineOptions: CutLineOptions;
  foilOptions: FoilMatrixOptions;
  selectedSlotIndex: number | null;
  onSelectSlot: (index: number) => void;
  onDuplicateSlotToAll: (index: number) => void;
  onClearSlot: (index: number) => void;
  onRotateSlot: (index: number) => void;
  onUploadImage?: (file: File, applyToAll: boolean) => void;
}

export const A4Workspace: React.FC<A4WorkspaceProps> = ({
  layout,
  artworks,
  defaultArt,
  cutLineOptions,
  foilOptions,
  selectedSlotIndex,
  onSelectSlot,
  onDuplicateSlotToAll,
  onClearSlot,
  onRotateSlot,
  onUploadImage,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [zoomScale, setZoomScale] = useState<number>(0.85);
  const [isDraggingOver, setIsDraggingOver] = useState<boolean>(false);

  useEffect(() => {
    if (!containerRef.current) return;
    const { clientWidth, clientHeight } = containerRef.current;
    const padding = 60;
    const availW = clientWidth - padding;
    const availH = clientHeight - padding;

    const baseMmToPx = 2.8;
    const naturalWidthPx = layout.pageWidthMm * baseMmToPx;
    const naturalHeightPx = layout.pageHeightMm * baseMmToPx;

    const scaleW = availW / naturalWidthPx;
    const scaleH = availH / naturalHeightPx;
    const bestScale = Math.min(scaleW, scaleH, 1.2);

    setZoomScale(Math.max(0.4, Math.round(bestScale * 100) / 100));
  }, [layout.orientation]);

  const mmToPx = 3.0 * zoomScale;
  const sheetWidthPx = layout.pageWidthMm * mmToPx;
  const sheetHeightPx = layout.pageHeightMm * mmToPx;

  const shape = layout.shape;

  // Check if sheet is completely empty
  const hasAnyImage = Boolean(
    (defaultArt && defaultArt.dataUrl) ||
    Object.values(artworks).some((a) => a && a.dataUrl)
  );

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(true);
  };

  const handleDragLeave = () => {
    setIsDraggingOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0] && onUploadImage) {
      onUploadImage(e.dataTransfer.files[0], true);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0] && onUploadImage) {
      onUploadImage(e.target.files[0], true);
      e.target.value = '';
    }
  };

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className="flex-1 flex flex-col h-full bg-slate-100/80 overflow-hidden relative select-none"
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileInputChange}
        accept="image/*"
        className="hidden"
      />

      {/* Top Floating Utility Bar */}
      <div className="no-print h-10 bg-white/95 backdrop-blur-xs border-b border-slate-200/90 px-4 flex items-center justify-between text-xs text-slate-600 z-10 shrink-0">
        <div className="flex items-center gap-3">
          <span className="font-bold text-slate-900">
            Folha A4: {layout.pageWidthMm} × {layout.pageHeightMm} mm
          </span>
          <span className="text-slate-300">|</span>
          <span className="text-slate-600 font-medium">
            {layout.totalPositions} bottons ({layout.cols} col × {layout.rows} lin)
          </span>
          <span className="text-slate-300">|</span>
          <span className="text-slate-500 font-medium hidden sm:inline">
            Face: {layout.innerDiameterMm} mm • Corte: {layout.outerDiameterMm} mm
          </span>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setZoomScale((prev) => Math.max(0.35, prev - 0.1))}
            className="p-1 rounded hover:bg-slate-100 text-slate-700 cursor-pointer"
            title="Reduzir zoom"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="font-mono text-xs w-12 text-center font-medium">
            {Math.round(zoomScale * 100)}%
          </span>
          <button
            type="button"
            onClick={() => setZoomScale((prev) => Math.min(2.0, prev + 0.1))}
            className="p-1 rounded hover:bg-slate-100 text-slate-700 cursor-pointer"
            title="Aumentar zoom"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setZoomScale(0.85)}
            className="px-2 py-0.5 rounded text-[11px] bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium cursor-pointer ml-1"
          >
            Ajustar
          </button>
        </div>
      </div>

      {/* Main Canvas Viewport */}
      <div
        ref={containerRef}
        className="flex-1 overflow-auto p-8 flex items-center justify-center relative"
      >
        {/* Drag Overlay Feedback */}
        {isDraggingOver && (
          <div className="absolute inset-8 z-30 bg-indigo-600/10 backdrop-blur-2xs border-2 border-dashed border-indigo-500 rounded-2xl flex flex-col items-center justify-center pointer-events-none animate-in fade-in">
            <UploadCloud className="w-12 h-12 text-indigo-600 animate-bounce mb-2" />
            <span className="text-sm font-bold text-indigo-900">
              Solte a imagem para preencher toda a folha
            </span>
          </div>
        )}

        {/* Empty State Banner if no image has been loaded */}
        {!hasAnyImage && (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="no-print absolute top-12 z-20 bg-white/95 hover:bg-white text-slate-700 border border-slate-200/90 shadow-md rounded-full px-4 py-2 flex items-center gap-2 cursor-pointer transition-all hover:scale-102 hover:border-indigo-400 group"
          >
            <Plus className="w-4 h-4 text-indigo-600 group-hover:rotate-90 transition-transform" />
            <span className="text-xs font-semibold text-slate-800">
              Folha limpa • Clique aqui ou em qualquer botton para inserir sua imagem
            </span>
          </div>
        )}

        <div
          className="print-only-sheet bg-white shadow-xl rounded-xs relative transition-all duration-150 border border-slate-300"
          style={{
            width: `${sheetWidthPx}px`,
            height: `${sheetHeightPx}px`,
            minWidth: `${sheetWidthPx}px`,
            minHeight: `${sheetHeightPx}px`,
          }}
        >
          {/* Margin Boundary Box */}
          <div
            className="no-print absolute pointer-events-none border border-dashed border-indigo-200/70"
            style={{
              top: `${layout.marginEffective.top * mmToPx}px`,
              left: `${layout.marginEffective.left * mmToPx}px`,
              right: `${layout.marginEffective.right * mmToPx}px`,
              bottom: `${layout.marginEffective.bottom * mmToPx}px`,
            }}
          />

          {/* Botton Items Grid */}
          {layout.positions.map((pos) => {
            const art = artworks[pos.index] || defaultArt;
            const hasImage = Boolean(art && art.dataUrl);
            const isSelected = selectedSlotIndex === pos.index;

            const outerWPx = layout.outerDiameterMm * mmToPx;
            const outerHPx = (layout.outerSecondaryMm || layout.outerDiameterMm) * mmToPx;
            const innerWPx = layout.innerDiameterMm * mmToPx;
            const innerHPx = (layout.innerSecondaryMm || layout.innerDiameterMm) * mmToPx;

            const centerXPx = pos.x * mmToPx;
            const posYPx = pos.y * mmToPx;

            const bleedType: BleedType = art?.bleedType || 'image_continuous';
            const bleedColor = art?.bleedColor || '#ffffff';
            const faceBgColor = art?.faceBgColor || '#ffffff';

            const borderRadiusStyle =
              shape === 'round'
                ? '9999px'
                : shape === 'heart'
                ? '0'
                : '6px';

            const imageTransform = `scale(${art?.scale || 1}) translate(${
              ((art?.panX || 0) / layout.outerDiameterMm) * 100
            }%, ${
              ((art?.panY || 0) / (layout.outerSecondaryMm || layout.outerDiameterMm)) * 100
            }%) rotate(${art?.rotation || 0}deg)`;

            return (
              <div
                key={pos.index}
                onClick={() => {
                  if (!hasImage && !hasAnyImage) {
                    fileInputRef.current?.click();
                  } else {
                    onSelectSlot(pos.index);
                  }
                }}
                className={`absolute group cursor-pointer transition-transform ${
                  isSelected ? 'z-20' : 'z-10'
                }`}
                style={{
                  width: `${outerWPx}px`,
                  height: `${outerHPx}px`,
                  left: `${centerXPx - outerWPx / 2}px`,
                  top: `${posYPx - outerHPx / 2}px`,
                }}
              >
                {/* Outer Cut Area Container */}
                <div
                  className="w-full h-full relative overflow-hidden flex items-center justify-center shadow-2xs transition-colors"
                  style={{
                    backgroundColor: hasImage
                      ? bleedType === 'solid_color'
                        ? bleedColor
                        : faceBgColor || '#ffffff'
                      : '#ffffff',
                    borderRadius: borderRadiusStyle,
                  }}
                >
                  {/* Rendering when Image is Present */}
                  {hasImage ? (
                    bleedType === 'image_continuous' ? (
                      <img
                        src={art.dataUrl}
                        alt={`Botton ${pos.index + 1}`}
                        className={`w-full h-full object-cover select-none pointer-events-none ${
                          foilOptions.enabled && foilOptions.invert ? 'filter invert' : ''
                        } ${foilOptions.enabled ? 'filter grayscale contrast-200' : ''}`}
                        style={{ transform: imageTransform }}
                      />
                    ) : bleedType === 'image_mirror' ? (
                      <>
                        <img
                          src={art.dataUrl}
                          alt=""
                          className="absolute inset-0 w-full h-full object-cover filter brightness-95 scale-x-[-1.1] scale-y-[-1.1]"
                          style={{ transform: imageTransform }}
                        />
                        <div
                          className="relative overflow-hidden flex items-center justify-center shadow-xs"
                          style={{
                            width: `${innerWPx}px`,
                            height: `${innerHPx}px`,
                            borderRadius: borderRadiusStyle,
                          }}
                        >
                          <img
                            src={art.dataUrl}
                            alt=""
                            className="w-full h-full object-cover"
                            style={{ transform: imageTransform }}
                          />
                        </div>
                      </>
                    ) : bleedType === 'image_blur' ? (
                      <>
                        <img
                          src={art.dataUrl}
                          alt=""
                          className="absolute inset-0 w-full h-full object-cover filter blur-[6px] scale-110 opacity-80"
                          style={{ transform: imageTransform }}
                        />
                        <div
                          className="relative overflow-hidden flex items-center justify-center shadow-xs"
                          style={{
                            width: `${innerWPx}px`,
                            height: `${innerHPx}px`,
                            borderRadius: borderRadiusStyle,
                          }}
                        >
                          <img
                            src={art.dataUrl}
                            alt=""
                            className="w-full h-full object-cover"
                            style={{ transform: imageTransform }}
                          />
                        </div>
                      </>
                    ) : (
                      <div
                        className="relative overflow-hidden flex items-center justify-center"
                        style={{
                          width: `${innerWPx}px`,
                          height: `${innerHPx}px`,
                          backgroundColor: faceBgColor,
                          borderRadius: borderRadiusStyle,
                        }}
                      >
                        <img
                          src={art.dataUrl}
                          alt=""
                          className="w-full h-full object-cover"
                          style={{ transform: imageTransform }}
                        />
                      </div>
                    )
                  ) : (
                    /* Clean Blank Empty Slot */
                    <div className="w-full h-full flex flex-col items-center justify-center bg-slate-50/70 group-hover:bg-indigo-50/40 transition-colors">
                      <div className="w-5 h-5 rounded-full bg-slate-200/70 group-hover:bg-indigo-100 flex items-center justify-center text-slate-400 group-hover:text-indigo-600 transition-colors mb-0.5">
                        <Plus className="w-3 h-3 stroke-[2.5]" />
                      </div>
                      <span className="text-[9px] font-mono font-medium text-slate-400 group-hover:text-indigo-600 transition-colors">
                        #{pos.index + 1}
                      </span>
                    </div>
                  )}

                  {/* Rim Text in Bleed Area */}
                  {art?.rimText && shape === 'round' && hasImage && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-[8px] font-semibold text-slate-500 opacity-60">
                      <span className="absolute bottom-1 truncate max-w-[80%] text-[7px] text-center bg-white/70 px-1 rounded">
                        {art.rimText}
                      </span>
                    </div>
                  )}

                  {/* Inner Face Boundary Guide (Dashed line) */}
                  {cutLineOptions.showInnerGuide && (
                    <div
                      className="no-print absolute pointer-events-none border border-dashed border-indigo-400"
                      style={{
                        width: `${innerWPx}px`,
                        height: `${innerHPx}px`,
                        borderRadius: borderRadiusStyle,
                        opacity: cutLineOptions.innerGuideOpacity || 0.45,
                      }}
                    />
                  )}

                  {/* Subtle Cut Line */}
                  {cutLineOptions.showCutLine && (
                    <div
                      className="absolute inset-0 pointer-events-none"
                      style={{
                        borderWidth: `${Math.max(1, cutLineOptions.cutLineWidthMm * mmToPx)}px`,
                        borderStyle: cutLineOptions.cutLineStyle,
                        borderColor: cutLineOptions.cutLineColor,
                        opacity: cutLineOptions.cutLineOpacity,
                        borderRadius: borderRadiusStyle,
                      }}
                    />
                  )}
                </div>

                {/* Selection ring */}
                {isSelected && (
                  <div
                    className="no-print absolute -inset-1 border-2 border-indigo-600 ring-2 ring-indigo-200 pointer-events-none"
                    style={{ borderRadius: borderRadiusStyle }}
                  />
                )}

                {/* Hover Toolbar when image is loaded */}
                {hasImage && (
                  <div className="no-print absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900/90 text-white px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1.5 shadow-lg text-[11px] pointer-events-auto">
                    <span className="font-mono text-[10px] font-bold text-slate-300 mr-0.5">
                      #{pos.index + 1}
                    </span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectSlot(pos.index);
                      }}
                      className="hover:text-indigo-300 p-0.5"
                      title="Ajustar zoom e sangria individual"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onRotateSlot(pos.index);
                      }}
                      className="hover:text-indigo-300 p-0.5"
                      title="Girar 90 graus"
                    >
                      <RotateCw className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDuplicateSlotToAll(pos.index);
                      }}
                      className="hover:text-indigo-300 p-0.5"
                      title="Copiar para todos"
                    >
                      <Copy className="w-3 h-3" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onClearSlot(pos.index);
                      }}
                      className="hover:text-red-300 p-0.5"
                      title="Limpar este botton"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}

          {/* Watermark */}
          <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-[9px] text-slate-400 font-mono pointer-events-none">
            <span>
              ZavaPrint - Botton Studio • A4 ({layout.pageWidthMm}×{layout.pageHeightMm}mm) • {layout.totalPositions} bottons {layout.innerDiameterMm}mm
            </span>
            <span>
              {foilOptions.enabled ? 'MATRIZ FOIL LASER' : 'IMPRESSÃO A4'}
            </span>
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="no-print h-9 bg-white border-t border-slate-200/90 px-4 flex items-center justify-between text-xs text-slate-600 shrink-0">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full border border-indigo-500 border-dashed inline-block" />
            <span>Face da Arte: {layout.innerDiameterMm} mm</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full border border-slate-400 inline-block opacity-60" />
            <span>Corte + Sangria: {layout.outerDiameterMm} mm</span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-500">
            <span>{hasAnyImage ? 'Arte inserida' : 'Modelo vazio (pronto para inserir arte)'}</span>
          </div>
        </div>
        <div className="text-[11px] text-slate-400 hidden sm:block">
          {hasAnyImage
            ? 'Clique em qualquer botton para ajustar zoom e posição'
            : 'Clique em um círculo ou arraste um arquivo de imagem para começar'}
        </div>
      </div>
    </div>
  );
};
